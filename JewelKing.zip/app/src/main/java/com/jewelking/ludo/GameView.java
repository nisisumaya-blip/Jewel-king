package com.jewelking.ludo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import com.jewelking.ludo.engine.Board;
import com.jewelking.ludo.engine.Game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Draws the whole game (board, pieces, dice, buttons) and handles touches.
 * Game rules live in {@link Game}; this class only shows and animates them.
 */
public final class GameView extends View {

    public interface Host {
        void onMenu();
        void onPlayAgain();
    }

    // ---------------------------------------------------------------- layout (design space 1024 x 1536)
    private static final float DW = 1024f, DH = 1536f;
    private static final float BX = 22f, BY = 365f, BW = 980f, BH = 880f;
    private static final float CW = BW / 15f, CH = BH / 15f;
    private static final float DICE_BOX = 128f;

    private static final int[] MAIN = {0xFFE5161B, 0xFF16A34A, 0xFFFFD60A, 0xFF1E88E5};
    private static final int[] DARK = {0xFF8F0A0E, 0xFF0B6B2D, 0xFFB89500, 0xFF11509C};

    private static final long DICE_MS = 520;
    private static final long STEP_MS = 95;
    private static final long EXIT_MS = 220;
    private static final long FLY_MS = 320;
    private static final long PASS_MS = 850;

    private enum Stage { IDLE, DICE, PASSWAIT, MOVING, CAPTURE }
    private enum Overlay { NONE, PAUSE }

    private final Game game;
    private final Store store;
    private final SoundFx fx;
    private final Host host;
    private final Random rnd = new Random();
    private Bitmap face;

    private Stage stage = Stage.IDLE;
    private long stageStart;
    private Overlay overlay = Overlay.NONE;
    private boolean hostPaused = false;
    private boolean overShown = false;

    // dice animation
    private double axX, axY, axZ;

    // move animation
    private int[][] disp;
    private Game.MoveResult mv;
    private int stepsFired;
    private int moveCur, moveRoll;   // whose turn / which number, while a move is still being shown

    // geometry (set in onSizeChanged)
    private float scale = 1f, offX = 0f, worldH = DH;
    private float dyTitle, dyTop, dyBoard, dyBottom, dyButtons;
    private Bitmap staticBmp;

    // paints
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();

    // hit areas (world coordinates)
    private final RectF btnSound = new RectF(), btnPause = new RectF();
    private final RectF btnA = new RectF(), btnB = new RectF();

    // pieces drawn in the last frame (for touch)
    private static final class PieceDraw {
        int seat, piece;
        float x, y, h;
        boolean valid;
    }
    private final ArrayList<PieceDraw> lastDraw = new ArrayList<PieceDraw>();

    public GameView(Context ctx, Game game, Store store, SoundFx fx, Host host) {
        super(ctx);
        this.game = game;
        this.store = store;
        this.fx = fx;
        this.host = host;
        face = BitmapFactory.decodeResource(getResources(), R.drawable.face);
        stroke.setStyle(Paint.Style.STROKE);
        fill.setStyle(Paint.Style.FILL);
        text.setTextAlign(Paint.Align.CENTER);
        settleAfterRestore();
    }

    // ================================================================ lifecycle

    private void settleAfterRestore() {
        // A restored game with a rolled-but-unusable die is handed on straight away.
        if (game.phase == Game.Phase.MOVE && game.validPieces().isEmpty()) {
            game.passTurn();
            store.saveGame(game);
        }
    }

    /** Called when the app goes to the background / screen locks. */
    public void onHostPause() {
        hostPaused = true;
        fx.stop();
        if (stage == Stage.DICE || stage == Stage.PASSWAIT) {
            if (game.phase == Game.Phase.MOVE && game.validPieces().isEmpty()) game.passTurn();
        }
        // The logical state is already final; animations just stop.
        stage = Stage.IDLE;
        disp = null;
        mv = null;
        store.saveGame(game);
    }

    public void onHostResume() {
        hostPaused = false;
        fx.resume();
        settleAfterRestore();
        postInvalidateOnAnimation();
    }

    public boolean handleBack() {
        if (overlay == Overlay.NONE) {
            overlay = Overlay.PAUSE;
        } else {
            overlay = Overlay.NONE;
        }
        invalidate();
        return true;
    }

    // ================================================================ sizing

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        scale = Math.min(w / DW, h / DH);
        offX = (w - DW * scale) / 2f;
        worldH = h / scale;
        float extra = Math.max(0f, worldH - DH);
        dyTitle = extra * 0.12f;
        dyTop = extra * 0.28f;
        dyBoard = extra * 0.50f;
        dyBottom = extra * 0.72f;
        dyButtons = extra * 0.90f;
        renderStatic(w, h);
    }

    private void renderStatic(int w, int h) {
        if (staticBmp != null) staticBmp.recycle();
        staticBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(staticBmp);
        c.translate(offX, 0f);
        c.scale(scale, scale);
        drawBackground(c);
        c.save();
        c.translate(0f, dyTitle);
        drawTitle(c);
        c.restore();
        c.save();
        c.translate(0f, dyBoard);
        drawBoardStatic(c);
        c.restore();
    }

    // ================================================================ static drawing

    private void drawBackground(Canvas c) {
        float left = -offX / scale;
        float right = left + getWidth() / scale;
        fill.setColor(0xFF1B49B8);
        c.drawRect(left, 0f, right, worldH, fill);
        // soft diamond pattern
        fill.setColor(0x14FFFFFF);
        float step = 170f;
        for (float y = -step; y < worldH + step; y += step) {
            for (float x = left - step; x < right + step; x += step) {
                float ox = (((int) (y / step)) % 2 == 0) ? 0f : step / 2f;
                path.reset();
                path.moveTo(x + ox, y - 60f);
                path.lineTo(x + ox + 60f, y);
                path.lineTo(x + ox, y + 60f);
                path.lineTo(x + ox - 60f, y);
                path.close();
                c.drawPath(path, fill);
            }
        }
        fill.setColor(0x10000000);
        for (float y = 0f; y < worldH; y += step) {
            for (float x = left; x < right; x += step) {
                c.drawCircle(x + 85f, y + 85f, 26f, fill);
            }
        }
    }

    private void drawTitle(Canvas c) {
        // crown
        float cx = DW / 2f;
        path.reset();
        path.moveTo(cx - 48f, 78f);
        path.lineTo(cx - 56f, 28f);
        path.lineTo(cx - 28f, 52f);
        path.lineTo(cx, 18f);
        path.lineTo(cx + 28f, 52f);
        path.lineTo(cx + 56f, 28f);
        path.lineTo(cx + 48f, 78f);
        path.close();
        fill.setColor(0xFFF5B400);
        c.drawPath(path, fill);
        stroke.setColor(0xFF7A4B00);
        stroke.setStrokeWidth(3f);
        c.drawPath(path, stroke);
        fill.setColor(0xFFD7141A);
        c.drawCircle(cx, 52f, 9f, fill);
        // name
        text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
        text.setTextSize(88f);
        text.setStyle(Paint.Style.STROKE);
        text.setStrokeWidth(12f);
        text.setColor(0xFF4A2A00);
        c.drawText("Jewel King", cx, 148f, text);
        text.setStyle(Paint.Style.FILL);
        text.setColor(0xFFFFC62A);
        c.drawText("Jewel King", cx, 148f, text);
        // capsule
        rect.set(cx - 135f, 158f, cx + 135f, 204f);
        fill.setColor(0xCC0B1F5C);
        c.drawRoundRect(rect, 23f, 23f, fill);
        stroke.setColor(0xFFF5B400);
        stroke.setStrokeWidth(3f);
        c.drawRoundRect(rect, 23f, 23f, stroke);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(27f);
        text.setColor(0xFFFFFFFF);
        c.drawText("\u0985\u09ab\u09b2\u09be\u0987\u09a8 \u2022 \u099f\u09bf\u09ae \u0986\u09aa", cx, 192f, text);
    }

    private float cellX(int col) { return BX + col * CW; }
    private float cellY(int row) { return BY + row * CH; }

    private void drawBoardStatic(Canvas c) {
        // frame
        rect.set(BX - 6f, BY - 6f, BX + BW + 6f, BY + BH + 6f);
        fill.setColor(0xFF2B2F3A);
        c.drawRoundRect(rect, 18f, 18f, fill);
        // bases
        int[][] baseOrigin = {{0, 0}, {9, 0}, {9, 9}, {0, 9}};   // {col,row} for RED, GREEN, YELLOW, BLUE
        for (int k = 0; k < 4; k++) {
            float x = cellX(baseOrigin[k][0]), y = cellY(baseOrigin[k][1]);
            fill.setColor(MAIN[k]);
            c.drawRect(x, y, x + 6f * CW, y + 6f * CH, fill);
            rect.set(x + 58f, y + 52f, x + 6f * CW - 58f, y + 6f * CH - 52f);
            fill.setColor(0xFFFFFFFF);
            c.drawRoundRect(rect, 10f, 10f, fill);
        }
        // track and home-column cells
        stroke.setColor(0xFF1A1A1A);
        stroke.setStrokeWidth(1.6f);
        for (int r = 0; r < 15; r++) {
            for (int col = 0; col < 15; col++) {
                boolean base = (r < 6 || r > 8) && (col < 6 || col > 8);
                boolean centre = r >= 6 && r <= 8 && col >= 6 && col <= 8;
                if (base || centre) continue;
                int colour = -1;
                if (r == 7 && col >= 1 && col <= 5) colour = Board.RED;
                else if (col == 7 && r >= 1 && r <= 5) colour = Board.GREEN;
                else if (r == 7 && col >= 9 && col <= 13) colour = Board.YELLOW;
                else if (col == 7 && r >= 9 && r <= 13) colour = Board.BLUE;
                for (int k = 0; k < 4; k++) {
                    int[] s = Board.cell(k, 0);
                    if (s[0] == r && s[1] == col) colour = k;
                }
                fill.setColor(colour >= 0 ? MAIN[colour] : 0xFFFFFFFF);
                c.drawRect(cellX(col), cellY(r), cellX(col) + CW, cellY(r) + CH, fill);
                c.drawRect(cellX(col), cellY(r), cellX(col) + CW, cellY(r) + CH, stroke);
            }
        }
        // stars
        for (int t : Board.starTracks()) {
            int[] rc = Board.trackCell(t);
            drawStar(c, cellX(rc[1]) + CW / 2f, cellY(rc[0]) + CH / 2f, Math.min(CW, CH) * 0.36f);
        }
        // arrows at the four entrances
        drawArrow(c, 0, 7, 1, 0, MAIN[Board.RED]);
        drawArrow(c, 7, 0, 0, 1, MAIN[Board.GREEN]);
        drawArrow(c, 14, 7, -1, 0, MAIN[Board.YELLOW]);
        drawArrow(c, 7, 14, 0, -1, MAIN[Board.BLUE]);
        // centre triangles
        float x0 = cellX(6), y0 = cellY(6), w = 3f * CW, h = 3f * CH;
        float mx = x0 + w / 2f, my = y0 + h / 2f;
        drawTri(c, x0, y0, x0, y0 + h, mx, my, MAIN[Board.RED]);
        drawTri(c, x0, y0, x0 + w, y0, mx, my, MAIN[Board.GREEN]);
        drawTri(c, x0 + w, y0, x0 + w, y0 + h, mx, my, MAIN[Board.YELLOW]);
        drawTri(c, x0, y0 + h, x0 + w, y0 + h, mx, my, MAIN[Board.BLUE]);
        // face photo in the middle (cropped, not altered)
        float fs = 116f;
        rect.set(mx - fs / 2f, my - fs / 2f, mx + fs / 2f, my + fs / 2f);
        fill.setColor(0xFFFFFFFF);
        c.drawRoundRect(rect, 12f, 12f, fill);
        if (face != null) {
            RectF inner = new RectF(rect.left + 4f, rect.top + 4f, rect.right - 4f, rect.bottom - 4f);
            path.reset();
            path.addRoundRect(inner, 9f, 9f, Path.Direction.CW);
            c.save();
            c.clipPath(path);
            c.drawBitmap(face, null, inner, fill);
            c.restore();
        }
        stroke.setColor(0xFF1A1A1A);
        stroke.setStrokeWidth(2f);
        c.drawRoundRect(rect, 12f, 12f, stroke);
    }

    private void drawTri(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, int color) {
        path.reset();
        path.moveTo(ax, ay);
        path.lineTo(bx, by);
        path.lineTo(cx, cy);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(2f);
        c.drawPath(path, stroke);
    }

    private void drawStar(Canvas c, float cx, float cy, float r) {
        path.reset();
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            float rr = (i % 2 == 0) ? r : r * 0.45f;
            float x = cx + (float) Math.cos(ang) * rr;
            float y = cy + (float) Math.sin(ang) * rr;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        path.close();
        fill.setColor(0xFFFFFFFF);
        c.drawPath(path, fill);
        stroke.setColor(0xFF111111);
        stroke.setStrokeWidth(2.6f);
        c.drawPath(path, stroke);
    }

    /** Arrow in cell (col,row) pointing (dx,dy). */
    private void drawArrow(Canvas c, int col, int row, int dx, int dy, int color) {
        float cx = cellX(col) + CW / 2f, cy = cellY(row) + CH / 2f;
        float L = Math.min(CW, CH) * 0.34f;
        path.reset();
        // head
        float hx = cx + dx * L, hy = cy + dy * L;
        float px = -dy, py = dx;
        path.moveTo(hx, hy);
        path.lineTo(cx - dx * L * 0.2f + px * L * 0.9f, cy - dy * L * 0.2f + py * L * 0.9f);
        path.lineTo(cx - dx * L * 0.2f - px * L * 0.9f, cy - dy * L * 0.2f - py * L * 0.9f);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
        stroke.setColor(color);
        stroke.setStrokeWidth(7f);
        c.drawLine(cx - dx * L, cy - dy * L, cx - dx * L * 0.1f, cy - dy * L * 0.1f, stroke);
    }

    // ================================================================ panels, positions

    private RectF panelRect(int color) {
        switch (color) {
            case Board.RED:    rect.set(22f, 205f + dyTop, 410f, 350f + dyTop); break;
            case Board.GREEN:  rect.set(614f, 205f + dyTop, 1002f, 350f + dyTop); break;
            case Board.BLUE:   rect.set(22f, 1257f + dyBottom, 410f, 1405f + dyBottom); break;
            default:           rect.set(614f, 1257f + dyBottom, 1002f, 1405f + dyBottom); break;
        }
        return new RectF(rect);
    }

    private float[] cellCentre(int row, int col) {
        return new float[] {cellX(col) + CW / 2f, cellY(row) + CH / 2f + dyBoard};
    }

    private float[] baseSlot(int color, int piece) {
        int[][] origin = {{0, 0}, {9, 0}, {9, 9}, {0, 9}};
        float x = cellX(origin[color][0]);
        float y = cellY(origin[color][1]) + dyBoard;
        float sx = x + ((piece % 2 == 0) ? 132f : 259f);
        float sy = y + ((piece < 2) ? 121f : 231f);
        return new float[] {sx, sy};
    }

    /** Position of a piece with the given progress (-1 base .. 56 home). */
    private float[] posOf(int color, int piece, int progress) {
        if (progress < 0) return baseSlot(color, piece);
        int[] rc = Board.cell(color, progress);
        return cellCentre(rc[0], rc[1]);
    }

    private int progOf(int seat, int piece) {
        return disp != null ? disp[seat][piece] : game.prog[seat][piece];
    }

    // ================================================================ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        update(now);

        canvas.drawColor(0xFF1B49B8);
        if (staticBmp != null) canvas.drawBitmap(staticBmp, 0f, 0f, null);

        canvas.save();
        canvas.translate(offX, 0f);
        canvas.scale(scale, scale);

        drawPanels(canvas, now);
        drawPieces(canvas, now);
        drawButtons(canvas);
        if (overlay == Overlay.PAUSE) drawPauseOverlay(canvas);
        else if (game.phase == Game.Phase.OVER && stage == Stage.IDLE) drawOverOverlay(canvas);

        canvas.restore();
        if (!hostPaused) postInvalidateOnAnimation();
    }

    private void drawText(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold, float maxW) {
        text.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        text.setTextSize(size);
        text.setStyle(Paint.Style.FILL);
        if (maxW > 0f) {
            float w = text.measureText(s);
            if (w > maxW) text.setTextSize(size * maxW / w);
        }
        text.setTextAlign(align);
        text.setColor(color);
        c.drawText(s, x, y, text);
        text.setTextAlign(Paint.Align.CENTER);
    }

    private void drawPanels(Canvas c, long now) {
        double pulse = 0.5 + 0.5 * Math.sin(now * 0.008);
        for (int s = 0; s < game.seats; s++) {
            int color = game.seatColor[s];
            RectF p = panelRect(color);
            boolean moving = (stage == Stage.MOVING || stage == Stage.CAPTURE);
            int shownCur = moving ? moveCur : game.cur;
            boolean active = (game.phase != Game.Phase.OVER || moving) && (s == shownCur);
            // body
            fill.setColor(DARK[color]);
            c.drawRoundRect(p, 22f, 22f, fill);
            RectF top = new RectF(p.left, p.top, p.right, p.centerY());
            fill.setColor(MAIN[color]);
            c.drawRoundRect(top, 22f, 22f, fill);
            fill.setColor(MAIN[color]);
            c.drawRect(p.left + 4f, p.top + 40f, p.right - 4f, p.bottom - 20f, fill);
            // border
            if (active) {
                stroke.setColor(0x66FFF27A);
                stroke.setStrokeWidth(14f + (float) (pulse * 6f));
                c.drawRoundRect(p, 22f, 22f, stroke);
                stroke.setColor(0xFFFFF27A);
                stroke.setStrokeWidth(6f);
                c.drawRoundRect(p, 22f, 22f, stroke);
            } else {
                stroke.setColor(0xAA101830);
                stroke.setStrokeWidth(3f);
                c.drawRoundRect(p, 22f, 22f, stroke);
            }
            // pin icon + name + team
            float cy = p.centerY();
            drawPin(c, p.left + 52f, cy, 76f, color, 255, false);
            int textColor = (color == Board.YELLOW) ? 0xFF3A2A00 : 0xFFFFFFFF;
            drawText(c, game.names[s], p.left + 100f, cy - (game.mode == Game.Mode.TEAM ? 8f : -10f), 34f, textColor,
                    Paint.Align.LEFT, true, 150f);
            if (game.mode == Game.Mode.TEAM) {
                String team = game.teamOf(s) == 0 ? "TEAM A" : "TEAM B";
                RectF chip = new RectF(p.left + 100f, cy + 6f, p.left + 214f, cy + 40f);
                fill.setColor(0xE6FFFFFF);
                c.drawRoundRect(chip, 17f, 17f, fill);
                drawText(c, team, chip.centerX(), chip.centerY() + 8f, 22f, DARK[color], Paint.Align.CENTER, true, 100f);
            }
            // dice
            float dcx = p.right - 12f - DICE_BOX / 2f;
            float dcy = p.centerY();
            drawDiceFor(c, s, dcx, dcy, active, now);
        }
    }

    // ---- dice -----------------------------------------------------------

    // face frames (right, up, normal) for values 1..6; opposite faces sum to 7
    private static final double[][] FN = {null, {0, 0, 1}, {0, 1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, -1, 0}, {0, 0, -1}};
    private static final double[][] FR = {null, {1, 0, 0}, {1, 0, 0}, {0, 0, -1}, {0, 0, 1}, {1, 0, 0}, {-1, 0, 0}};
    private static final double[][] FU = {null, {0, 1, 0}, {0, 0, -1}, {0, 1, 0}, {0, 1, 0}, {0, 0, 1}, {0, 1, 0}};
    private static final double[][][] PIPS = {
        null,
        {{0, 0}},
        {{-0.5, 0.5}, {0.5, -0.5}},
        {{-0.5, 0.5}, {0, 0}, {0.5, -0.5}},
        {{-0.5, 0.5}, {0.5, 0.5}, {-0.5, -0.5}, {0.5, -0.5}},
        {{-0.5, 0.5}, {0.5, 0.5}, {0, 0}, {-0.5, -0.5}, {0.5, -0.5}},
        {{-0.5, 0.56}, {0.5, 0.56}, {-0.5, 0}, {0.5, 0}, {-0.5, -0.56}, {0.5, -0.56}}
    };
    private static final double LX = -0.348, LY = 0.497, LZ = 0.795;
    private static final double PERSP = 6.0;

    private static double[] rotation(double ux, double uy, double uz, double a) {
        double len = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= len; uy /= len; uz /= len;
        double c = Math.cos(a), s = Math.sin(a), t = 1 - c;
        return new double[] {
            t * ux * ux + c,       t * ux * uy - s * uz, t * ux * uz + s * uy,
            t * ux * uy + s * uz,  t * uy * uy + c,      t * uy * uz - s * ux,
            t * ux * uz - s * uy,  t * uy * uz + s * ux, t * uz * uz + c
        };
    }

    private static double[] mul(double[] a, double[] b) {
        double[] o = new double[9];
        for (int r = 0; r < 3; r++) {
            for (int col = 0; col < 3; col++) {
                o[r * 3 + col] = a[r * 3] * b[col] + a[r * 3 + 1] * b[3 + col] + a[r * 3 + 2] * b[6 + col];
            }
        }
        return o;
    }

    private static double[] apply(double[] m, double[] v) {
        return new double[] {
            m[0] * v[0] + m[1] * v[1] + m[2] * v[2],
            m[3] * v[0] + m[4] * v[1] + m[5] * v[2],
            m[6] * v[0] + m[7] * v[1] + m[8] * v[2]
        };
    }

    /** Orientation that shows value v flat and upright, facing the player. */
    private static double[] faceUp(int v) {
        return new double[] {
            FR[v][0], FR[v][1], FR[v][2],
            FU[v][0], FU[v][1], FU[v][2],
            FN[v][0], FN[v][1], FN[v][2]
        };
    }

    private void drawDiceFor(Canvas c, int seat, float cx, float cy, boolean active, long now) {
        double[] total;
        float s;
        int alpha = active ? 255 : 130;
        if (active && stage == Stage.DICE) {
            float t = Math.min(1f, (now - stageStart) / (float) DICE_MS);
            double a = 22.0 * (1 - t) * (1 - t);              // fast at first, glides to rest
            double[] q = rotation(axX, axY, axZ, a);
            total = mul(q, faceUp(game.roll));
            s = 34f + 12f * t * t * (3f - 2f * t);
            cy -= (float) Math.sin(Math.PI * t) * 9f;         // small hop, stays in place
        } else if (active && game.phase == Game.Phase.MOVE && game.roll >= 1) {
            total = faceUp(game.roll);                         // result: flat, upright, clear
            s = 46f;
        } else if (active && (stage == Stage.MOVING || stage == Stage.CAPTURE) && moveRoll >= 1) {
            total = faceUp(moveRoll);                          // keep the number until the piece has finished
            s = 46f;
        } else {
            // not rolled yet: cube resting at a slight angle
            total = mul(rotation(1, 0, 0, -0.55), rotation(0, 1, 0, 0.62));
            s = 36f;
        }
        drawCube(c, cx, cy, s, total, alpha);
    }

    private void drawCube(Canvas c, float cx, float cy, float s, double[] T, int alpha) {
        // soft shadow
        fill.setColor(((alpha * 70 / 255) << 24));
        rect.set(cx - s * 1.25f, cy + s * 1.1f, cx + s * 1.25f, cy + s * 1.1f + s * 0.4f);
        c.drawOval(rect, fill);
        double[][] corners = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int f = 1; f <= 6; f++) {
            double[] tn = apply(T, FN[f]);
            if (tn[2] <= 0.02) continue;                       // back faces
            double diff = Math.max(0.0, tn[0] * LX + tn[1] * LY + tn[2] * LZ);
            int g = (int) (255 * (0.66 + 0.32 * diff));
            int rgb = (alpha << 24) | (g << 16) | (g << 8) | g;
            path.reset();
            for (int k = 0; k < 4; k++) {
                double[] v = new double[3];
                for (int i = 0; i < 3; i++) v[i] = FN[f][i] + corners[k][0] * FR[f][i] + corners[k][1] * FU[f][i];
                float[] p = project(T, v, cx, cy, s);
                if (k == 0) path.moveTo(p[0], p[1]); else path.lineTo(p[0], p[1]);
            }
            path.close();
            fill.setColor(rgb);
            c.drawPath(path, fill);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setStrokeWidth(9f);
            stroke.setColor(rgb);
            c.drawPath(path, stroke);
            stroke.setStrokeWidth(2f);
            stroke.setColor((alpha * 90 / 255) << 24 | 0x00333344);
            c.drawPath(path, stroke);
            stroke.setStrokeJoin(Paint.Join.MITER);
            // pips
            int pg = (int) (20 * (1 + diff));
            fill.setColor((alpha << 24) | (pg << 16) | (pg << 8) | pg);
            for (double[] pip : PIPS[f]) {
                path.reset();
                for (int i = 0; i < 12; i++) {
                    double a = i * Math.PI / 6;
                    double lx = pip[0] * 1.0 + 0.17 * Math.cos(a);
                    double ly = pip[1] * 1.0 + 0.17 * Math.sin(a);
                    double[] v = new double[3];
                    for (int j = 0; j < 3; j++) v[j] = FN[f][j] + lx * FR[f][j] + ly * FU[f][j];
                    float[] p = project(T, v, cx, cy, s);
                    if (i == 0) path.moveTo(p[0], p[1]); else path.lineTo(p[0], p[1]);
                }
                path.close();
                c.drawPath(path, fill);
            }
        }
    }

    private float[] project(double[] T, double[] v, float cx, float cy, float s) {
        double[] t = apply(T, v);
        float k = (float) (PERSP / (PERSP - t[2]));
        return new float[] {cx + s * (float) t[0] * k, cy - s * (float) t[1] * k};
    }

    // ---- pieces -----------------------------------------------------------

    private static int shade(int color, float k) {
        int r = (int) (((color >> 16) & 0xFF) * k);
        int g = (int) (((color >> 8) & 0xFF) * k);
        int b = (int) ((color & 0xFF) * k);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    /** Map-pin piece centred on (cx,cy), total height h. */
    private void drawPin(Canvas c, float cx, float cy, float h, int color, int alpha, boolean glow) {
        float w = h * 0.68f;
        float r = w * 0.5f;
        float headY = cy - h * 0.14f;
        int a = alpha << 24;
        // base disc
        fill.setColor(a | (shade(MAIN[color], 0.75f) & 0xFFFFFF));
        rect.set(cx - w * 0.58f, cy + h * 0.28f, cx + w * 0.58f, cy + h * 0.46f);
        c.drawOval(rect, fill);
        fill.setColor(a | (MAIN[color] & 0xFFFFFF));
        rect.set(cx - w * 0.5f, cy + h * 0.26f, cx + w * 0.5f, cy + h * 0.41f);
        c.drawOval(rect, fill);
        // white teardrop
        path.reset();
        path.moveTo(cx, cy + h * 0.40f);
        path.cubicTo(cx - w * 0.12f, cy + h * 0.14f, cx - r, cy - h * 0.02f, cx - r, headY);
        rect.set(cx - r, headY - r, cx + r, headY + r);
        path.arcTo(rect, 180f, 180f);
        path.cubicTo(cx + r, cy - h * 0.02f, cx + w * 0.12f, cy + h * 0.14f, cx, cy + h * 0.40f);
        path.close();
        fill.setColor(a | 0xF2F2F2);
        c.drawPath(path, fill);
        stroke.setColor(a | 0x666666);
        stroke.setStrokeWidth(Math.max(1.5f, h * 0.02f));
        c.drawPath(path, stroke);
        // coloured ball
        fill.setColor(a | (MAIN[color] & 0xFFFFFF));
        c.drawCircle(cx, headY, r * 0.72f, fill);
        fill.setColor(a | (shade(MAIN[color], 0.7f) & 0xFFFFFF));
        rect.set(cx - r * 0.72f, headY, cx + r * 0.72f, headY + r * 0.72f);
        c.drawArc(rect, 20f, 140f, false, fill);
        fill.setColor((alpha * 200 / 255) << 24 | 0xFFFFFF);
        c.drawCircle(cx - r * 0.25f, headY - r * 0.25f, r * 0.2f, fill);
    }

    private void drawPieces(Canvas c, long now) {
        lastDraw.clear();
        Set<Integer> validIds = new HashSet<Integer>();
        boolean canPick = (stage == Stage.IDLE) && (overlay == Overlay.NONE) && game.phase == Game.Phase.MOVE;
        if (canPick) validIds.addAll(game.validPieces());

        HashMap<Integer, ArrayList<PieceDraw>> cells = new HashMap<Integer, ArrayList<PieceDraw>>();
        ArrayList<PieceDraw> all = new ArrayList<PieceDraw>();
        int[] finished = new int[game.seats];

        for (int s = 0; s < game.seats; s++) {
            int color = game.seatColor[s];
            for (int p = 0; p < 4; p++) {
                if (stage == Stage.MOVING && mv != null && mv.seat == s && mv.piece == p) continue;
                if (stage == Stage.CAPTURE && isFlying(s, p)) continue;
                int pr = progOf(s, p);
                if (pr == Board.HOME) { finished[s]++; continue; }
                PieceDraw d = new PieceDraw();
                d.seat = s;
                d.piece = p;
                d.valid = validIds.contains(s * 4 + p);
                if (pr < 0) {
                    float[] b = baseSlot(color, p);
                    d.x = b[0];
                    d.y = b[1];
                    d.h = 92f;
                    all.add(d);
                } else {
                    int[] rc = Board.cell(color, pr);
                    int key = rc[0] * 15 + rc[1];
                    ArrayList<PieceDraw> l = cells.get(key);
                    if (l == null) {
                        l = new ArrayList<PieceDraw>();
                        cells.put(key, l);
                    }
                    l.add(d);
                }
            }
        }
        for (java.util.Map.Entry<Integer, ArrayList<PieceDraw>> e : cells.entrySet()) {
            int row = e.getKey() / 15, col = e.getKey() % 15;
            float[] ctr = cellCentre(row, col);
            ArrayList<PieceDraw> l = e.getValue();
            int n = l.size();
            float hh = CH * 1.02f;
            float[][] off;
            if (n == 1) { off = new float[][] {{0f, 0f}}; }
            else if (n == 2) { off = new float[][] {{-0.2f * CW, 0.04f * CH}, {0.2f * CW, 0.04f * CH}}; hh *= 0.78f; }
            else if (n == 3) { off = new float[][] {{-0.24f * CW, 0.12f * CH}, {0.24f * CW, 0.12f * CH}, {0f, -0.14f * CH}}; hh *= 0.68f; }
            else { off = new float[][] {{-0.22f * CW, -0.14f * CH}, {0.22f * CW, -0.14f * CH}, {-0.22f * CW, 0.2f * CH}, {0.22f * CW, 0.2f * CH}}; hh *= 0.6f; }
            for (int i = 0; i < n; i++) {
                PieceDraw d = l.get(i);
                d.x = ctr[0] + off[Math.min(i, off.length - 1)][0];
                d.y = ctr[1] + off[Math.min(i, off.length - 1)][1];
                d.h = hh;
                all.add(d);
            }
        }
        Collections.sort(all, new Comparator<PieceDraw>() {
            @Override public int compare(PieceDraw a, PieceDraw b) { return Float.compare(a.y, b.y); }
        });
        for (PieceDraw d : all) {
            float bounce = 0f;
            if (d.valid) {
                double ph = 0.5 + 0.5 * Math.sin(now * 0.009);
                bounce = -(float) (ph * d.h * 0.12f);
                fill.setColor(0x99FFF27A);
                rect.set(d.x - d.h * 0.5f, d.y + d.h * 0.22f, d.x + d.h * 0.5f, d.y + d.h * 0.52f);
                c.drawOval(rect, fill);
                stroke.setColor(0xFFFFFFFF);
                stroke.setStrokeWidth(3f);
                c.drawOval(rect, stroke);
            }
            drawPin(c, d.x, d.y + bounce, d.h, game.seatColor[d.seat], 255, d.valid);
            PieceDraw rec = new PieceDraw();
            rec.seat = d.seat; rec.piece = d.piece; rec.x = d.x; rec.y = d.y; rec.h = d.h; rec.valid = d.valid;
            lastDraw.add(rec);
        }
        drawGems(c, finished);
        drawMover(c, now);
    }

    /** Pieces that reached home sit as small gems in their colour's triangle. */
    private void drawGems(Canvas c, int[] finished) {
        float mx = cellX(7) + CW / 2f, my = cellY(7) + CH / 2f + dyBoard;
        for (int s = 0; s < game.seats; s++) {
            int color = game.seatColor[s];
            for (int k = 0; k < finished[s]; k++) {
                float o = (k - 1.5f) * 21f;
                float gx, gy;
                switch (color) {
                    case Board.RED:    gx = mx - 78f; gy = my + o; break;
                    case Board.GREEN:  gx = mx + o;  gy = my - 72f; break;
                    case Board.YELLOW: gx = mx + 78f; gy = my + o; break;
                    default:           gx = mx + o;  gy = my + 72f; break;
                }
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(gx, gy, 10.5f, fill);
                fill.setColor(shade(MAIN[color], 0.85f));
                c.drawCircle(gx, gy, 8f, fill);
            }
        }
    }

    private boolean isFlying(int seat, int piece) {
        if (mv == null) return false;
        for (int[] cap : mv.captured) if (cap[0] == seat && cap[1] == piece) return true;
        return false;
    }

    private static float ease(float u) {
        return u * u * (3f - 2f * u);
    }

    private void drawMover(Canvas c, long now) {
        if (mv == null) return;
        int color = game.seatColor[mv.seat];
        float h = CH * 1.12f;
        if (stage == Stage.MOVING) {
            int n = mv.path.length;
            long stepMs = (mv.fromProgress < 0) ? EXIT_MS : STEP_MS;
            float tt = (now - stageStart) / (float) stepMs;
            int i = Math.min(n - 1, (int) tt);
            float u = Math.min(1f, tt - i);
            int from = (i == 0) ? mv.fromProgress : mv.path[i - 1];
            int to = mv.path[i];
            float[] a = posOf(color, mv.piece, from);
            float[] b = posOf(color, mv.piece, to);
            float e = ease(u);
            float x = a[0] + (b[0] - a[0]) * e;
            float y = a[1] + (b[1] - a[1]) * e - (float) Math.sin(Math.PI * u) * 16f;
            drawPin(c, x, y, h, color, 255, false);
        } else if (stage == Stage.CAPTURE) {
            float u = Math.min(1f, (now - stageStart) / (float) FLY_MS);
            for (int[] cap : mv.captured) {
                float[] a = posOf(game.seatColor[cap[0]], cap[1], cap[2]);
                float[] b = baseSlot(game.seatColor[cap[0]], cap[1]);
                float e = ease(u);
                float x = a[0] + (b[0] - a[0]) * e;
                float y = a[1] + (b[1] - a[1]) * e - (float) Math.sin(Math.PI * u) * 40f;
                drawPin(c, x, y, h + (92f - h) * e, game.seatColor[cap[0]], 255, false);
            }
        }
    }

    // ---- buttons and overlays -----------------------------------------------

    private void drawButtons(Canvas c) {
        float cy = 1447f + dyButtons;
        btnSound.set(416f - 55f, cy - 55f, 416f + 55f, cy + 55f);
        btnPause.set(611f - 55f, cy - 55f, 611f + 55f, cy + 55f);
        drawRoundButton(c, btnSound);
        drawRoundButton(c, btnPause);
        // speaker
        float sx = btnSound.centerX(), sy = btnSound.centerY();
        path.reset();
        path.moveTo(sx - 26f, sy - 10f);
        path.lineTo(sx - 12f, sy - 10f);
        path.lineTo(sx + 6f, sy - 26f);
        path.lineTo(sx + 6f, sy + 26f);
        path.lineTo(sx - 12f, sy + 10f);
        path.lineTo(sx - 26f, sy + 10f);
        path.close();
        fill.setColor(0xFFFFFFFF);
        c.drawPath(path, fill);
        if (fx.isMuted()) {
            stroke.setColor(0xFFFF4B4B);
            stroke.setStrokeWidth(8f);
            c.drawLine(sx + 14f, sy - 14f, sx + 36f, sy + 14f, stroke);
            c.drawLine(sx + 36f, sy - 14f, sx + 14f, sy + 14f, stroke);
        } else {
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(5f);
            rect.set(sx - 6f, sy - 16f, sx + 22f, sy + 16f);
            c.drawArc(rect, -50f, 100f, false, stroke);
            rect.set(sx - 6f, sy - 28f, sx + 34f, sy + 28f);
            c.drawArc(rect, -50f, 100f, false, stroke);
        }
        // pause bars
        fill.setColor(0xFFFFFFFF);
        float px = btnPause.centerX(), py = btnPause.centerY();
        rect.set(px - 20f, py - 24f, px - 6f, py + 24f);
        c.drawRoundRect(rect, 4f, 4f, fill);
        rect.set(px + 6f, py - 24f, px + 20f, py + 24f);
        c.drawRoundRect(rect, 4f, 4f, fill);
    }

    private void drawRoundButton(Canvas c, RectF r) {
        fill.setColor(0xFF0B2A78);
        c.drawOval(r, fill);
        stroke.setColor(0xFFF5B400);
        stroke.setStrokeWidth(7f);
        c.drawOval(r, stroke);
    }

    private void drawCard(Canvas c, float h) {
        fill.setColor(0xBB000010);
        c.drawRect(-offX / scale, 0f, -offX / scale + getWidth() / scale, worldH, fill);
        float cy = worldH / 2f;
        rect.set(162f, cy - h / 2f, 862f, cy + h / 2f);
        fill.setColor(0xFF10307F);
        c.drawRoundRect(rect, 30f, 30f, fill);
        stroke.setColor(0xFFF5B400);
        stroke.setStrokeWidth(6f);
        c.drawRoundRect(rect, 30f, 30f, stroke);
    }

    private void drawBigButton(Canvas c, RectF r, String label, int color) {
        fill.setColor(color);
        c.drawRoundRect(r, 26f, 26f, fill);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(4f);
        c.drawRoundRect(r, 26f, 26f, stroke);
        drawText(c, label, r.centerX(), r.centerY() + 14f, 40f, 0xFFFFFFFF, Paint.Align.CENTER, true, r.width() - 30f);
    }

    private void drawPauseOverlay(Canvas c) {
        drawCard(c, 460f);
        float cy = worldH / 2f;
        drawText(c, "\u09ac\u09bf\u09b0\u09a4\u09bf", 512f, cy - 130f, 58f, 0xFFFFC62A, Paint.Align.CENTER, true, 500f);
        btnA.set(262f, cy - 80f, 762f, cy + 20f);
        btnB.set(262f, cy + 50f, 762f, cy + 150f);
        drawBigButton(c, btnA, "\u099a\u09be\u09b2\u09bf\u09af\u09bc\u09c7 \u09af\u09be\u09a8", 0xFF16A34A);
        drawBigButton(c, btnB, "\u09a8\u09a4\u09c1\u09a8 \u0996\u09c7\u09b2\u09be / \u09ae\u09c7\u09a8\u09c1", 0xFFC2410C);
    }

    private static String ordinal(int i) {
        String[] o = {"\u09e7\u09ae", "\u09e8\u09af\u09bc", "\u09e9\u09af\u09bc", "\u09ea\u09b0\u09cd\u09a5"};
        return o[Math.min(i, 3)];
    }

    private void drawOverOverlay(Canvas c) {
        boolean team = game.mode == Game.Mode.TEAM;
        drawCard(c, team ? 560f : 640f);
        float cy = worldH / 2f;
        float top = cy - (team ? 280f : 320f);
        drawText(c, "\u0996\u09c7\u09b2\u09be \u09b6\u09c7\u09b7!", 512f, top + 80f, 62f, 0xFFFFC62A, Paint.Align.CENTER, true, 600f);
        if (team) {
            String t = (game.winnerTeam == 0) ? "TEAM A" : "TEAM B";
            drawText(c, t + " \u099c\u09af\u09bc\u09c0!", 512f, top + 165f, 54f, 0xFFFFFFFF, Paint.Align.CENTER, true, 600f);
            StringBuilder sb = new StringBuilder();
            for (int s = 0; s < game.seats; s++) {
                if (game.teamOf(s) == game.winnerTeam) {
                    if (sb.length() > 0) sb.append("  &  ");
                    sb.append(game.names[s]);
                }
            }
            drawText(c, sb.toString(), 512f, top + 230f, 40f, 0xFFFFF27A, Paint.Align.CENTER, true, 600f);
        } else {
            for (int i = 0; i < game.ranking.size(); i++) {
                int seat = game.ranking.get(i);
                float y = top + 160f + i * 62f;
                drawText(c, ordinal(i) + ":", 262f, y, 42f, 0xFFFFF27A, Paint.Align.LEFT, true, 120f);
                drawText(c, game.names[seat], 390f, y, 42f, 0xFFFFFFFF, Paint.Align.LEFT, true, 420f);
                fill.setColor(MAIN[game.seatColor[seat]]);
                c.drawCircle(792f, y - 14f, 16f, fill);
            }
        }
        float by = cy + (team ? 70f : 110f);
        btnA.set(262f, by, 762f, by + 90f);
        btnB.set(262f, by + 112f, 762f, by + 202f);
        drawBigButton(c, btnA, "\u0986\u09ac\u09be\u09b0 \u0996\u09c7\u09b2\u09c1\u09a8", 0xFF16A34A);
        drawBigButton(c, btnB, "\u09ae\u09c7\u09a8\u09c1", 0xFFC2410C);
    }

    // ================================================================ state machine

    private void update(long now) {
        if (hostPaused) return;
        switch (stage) {
            case DICE:
                if (now - stageStart >= DICE_MS) {
                    fx.say(game.roll);
                    if (game.validPieces().isEmpty()) {
                        stage = Stage.PASSWAIT;
                        stageStart = now;
                    } else {
                        stage = Stage.IDLE;
                    }
                }
                break;
            case PASSWAIT:
                if (now - stageStart >= PASS_MS) {
                    game.passTurn();
                    store.saveGame(game);
                    stage = Stage.IDLE;
                }
                break;
            case MOVING: {
                int n = mv.path.length;
                long stepMs = (mv.fromProgress < 0) ? EXIT_MS : STEP_MS;
                int due = (int) Math.min((long) n, (now - stageStart) / stepMs + 1);
                while (stepsFired < due) {
                    fx.tip();
                    stepsFired++;
                }
                if (now - stageStart >= stepMs * n) {
                    disp[mv.seat][mv.piece] = mv.toProgress;
                    if (mv.reachedHome) fx.home();
                    else if (mv.landedOnStar) fx.star();
                    if (!mv.captured.isEmpty()) {
                        fx.cut();
                        stage = Stage.CAPTURE;
                        stageStart = now;
                    } else {
                        finishMove();
                    }
                }
                break;
            }
            case CAPTURE:
                if (now - stageStart >= FLY_MS) finishMove();
                break;
            default:
                break;
        }
    }

    private void finishMove() {
        disp = null;
        mv = null;
        stage = Stage.IDLE;
    }

    private void startRoll() {
        if (game.phase != Game.Phase.ROLL) return;
        int v = game.roll(rnd);                      // result decided and stored once, here
        if (v == 0) return;
        store.saveGame(game);
        double ax = rnd.nextDouble() - 0.5, ay = rnd.nextDouble() - 0.5, az = (rnd.nextDouble() - 0.5) * 0.4;
        if (Math.abs(ax) + Math.abs(ay) < 0.1) ax = 0.4;
        axX = ax;
        axY = ay;
        axZ = az;
        stage = Stage.DICE;
        stageStart = SystemClock.uptimeMillis();
    }

    private void startMove(int seat, int piece) {
        int[][] before = new int[game.seats][4];
        for (int s = 0; s < game.seats; s++) System.arraycopy(game.prog[s], 0, before[s], 0, 4);
        int curBefore = game.cur;
        int rollBefore = game.roll;
        Game.MoveResult res = game.move(seat, piece);
        if (res == null) return;
        moveCur = curBefore;
        moveRoll = rollBefore;
        store.saveGame(game);                        // state is final and saved before any animation
        disp = before;
        mv = res;
        stepsFired = 0;
        stage = Stage.MOVING;
        stageStart = SystemClock.uptimeMillis();
    }

    // ================================================================ touch

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() != MotionEvent.ACTION_DOWN) return true;
        float x = (ev.getX() - offX) / scale;
        float y = ev.getY() / scale;

        if (overlay == Overlay.PAUSE) {
            if (btnA.contains(x, y)) {
                overlay = Overlay.NONE;
            } else if (btnB.contains(x, y)) {
                host.onMenu();
            }
            invalidate();
            return true;
        }
        if (game.phase == Game.Phase.OVER && stage == Stage.IDLE) {
            if (btnA.contains(x, y)) host.onPlayAgain();
            else if (btnB.contains(x, y)) host.onMenu();
            return true;
        }
        if (btnSound.contains(x, y)) {
            fx.setMuted(!fx.isMuted());
            store.setMuted(fx.isMuted());
            invalidate();
            return true;
        }
        if (btnPause.contains(x, y)) {
            overlay = Overlay.PAUSE;
            invalidate();
            return true;
        }
        if (stage != Stage.IDLE) return true;        // busy: extra taps are ignored

        if (game.phase == Game.Phase.ROLL) {
            RectF p = panelRect(game.seatColor[game.cur]);
            if (p.contains(x, y)) startRoll();       // whole panel is the touch area
            return true;
        }
        if (game.phase == Game.Phase.MOVE) {
            PieceDraw best = null;
            float bestD = Float.MAX_VALUE;
            for (PieceDraw d : lastDraw) {
                if (!d.valid) continue;
                float dx = d.x - x, dy = d.y - y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float reach = Math.max(CW * 0.95f, d.h * 0.7f);
                if (dist < reach && dist < bestD) {
                    bestD = dist;
                    best = d;
                }
            }
            if (best != null) startMove(best.seat, best.piece);
        }
        return true;
    }
}
