package com.jewelking.ludo.engine;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Jewel King rules engine. No Android dependencies.
 *
 * Every state change (roll / move / pass) is applied to the logical state
 * immediately and exactly once; the UI animates afterwards. Because the whole
 * state can be serialised after each step, a restored game can never repeat a
 * move or a capture.
 */
public final class Game {

    public enum Mode { SOLO2, SOLO4, TEAM }
    public enum Phase { ROLL, MOVE, OVER }

    /** What happened when a piece was moved (used for animation and sound). */
    public static final class MoveResult {
        public int seat, piece, fromProgress, toProgress;
        /** Progress values visited, in order (first entry is the first square entered). */
        public int[] path;
        /** Each entry: {seat, piece, progressBeforeCapture}. */
        public final List<int[]> captured = new ArrayList<int[]>();
        public boolean reachedHome, landedOnStar, extraTurn, gameOver;
    }

    public final Mode mode;
    /** Colour of each seat, in clockwise turn order (ascending colour id). */
    public final int[] seatColor;
    public final String[] names;
    public final int seats;
    /** prog[seat][piece]. */
    public final int[][] prog;

    public int cur;
    public int sixes;
    public int roll;
    public Phase phase = Phase.ROLL;
    /** Finishing order of seats (solo modes). */
    public final List<Integer> ranking = new ArrayList<Integer>();
    /** TEAM mode winner: 0 = Team A (blue + green), 1 = Team B (red + yellow); -1 = none. */
    public int winnerTeam = -1;

    public Game(Mode mode, int[] seatColor, String[] names, Random rnd) {
        this.mode = mode;
        this.seats = seatColor.length;
        if (mode == Mode.SOLO2 && seats != 2) throw new IllegalArgumentException("SOLO2 needs 2 seats");
        if (mode != Mode.SOLO2 && seats != 4) throw new IllegalArgumentException("4 seats needed");
        for (int i = 1; i < seats; i++) {
            if (seatColor[i] <= seatColor[i - 1]) throw new IllegalArgumentException("colours must ascend");
        }
        this.seatColor = seatColor.clone();
        this.names = names.clone();
        this.prog = new int[seats][4];
        for (int s = 0; s < seats; s++) for (int p = 0; p < 4; p++) prog[s][p] = -1;
        this.cur = rnd.nextInt(seats);
    }

    // ------------------------------------------------------------ teams

    /** Team id of a seat. In TEAM mode: 0 = A (green, blue), 1 = B (red, yellow). */
    public int teamOf(int seat) {
        if (mode != Mode.TEAM) return seat;
        int c = seatColor[seat];
        return (c == Board.GREEN || c == Board.BLUE) ? 0 : 1;
    }

    public int friendSeat(int seat) {
        return mode == Mode.TEAM ? (seat + 2) % 4 : -1;
    }

    public boolean seatFinished(int seat) {
        for (int p = 0; p < 4; p++) if (prog[seat][p] != Board.HOME) return false;
        return true;
    }

    /** The seat whose pieces the current player may move. */
    public int controlSeat() {
        if (mode == Mode.TEAM && seatFinished(cur)) return friendSeat(cur);
        return cur;
    }

    // ------------------------------------------------------------ dice

    /**
     * Throws the dice for the current player: decides the result once and
     * stores it. Returns the value (0 if a roll is not allowed now).
     */
    public int roll(Random rnd) {
        if (phase != Phase.ROLL) return 0;
        int v = (sixes >= 2) ? 1 + rnd.nextInt(5) : 1 + rnd.nextInt(6);
        if (v == 6) sixes++; else sixes = 0;
        roll = v;
        phase = Phase.MOVE;
        return v;
    }

    // ------------------------------------------------------------ legality

    /** Is moving (seat, piece) by r legal right now? */
    public boolean canMove(int seat, int piece, int r) {
        int p = prog[seat][piece];
        if (p == Board.HOME) return false;
        int q;
        if (p == -1) {
            if (r != 6) return false;
            q = 0;
        } else {
            q = p + r;
            if (q > Board.HOME) return false;
        }
        if (q == Board.HOME) return true;
        // A player's own pieces may never share a square.
        for (int j = 0; j < 4; j++) {
            if (j == piece) continue;
            if (prog[seat][j] == q && q >= 0) return false;
        }
        return true;
    }

    /** Valid piece ids (seat*4+piece) for the pending roll. */
    public List<Integer> validPieces() {
        List<Integer> out = new ArrayList<Integer>();
        if (phase != Phase.MOVE) return out;
        int cs = controlSeat();
        for (int i = 0; i < 4; i++) if (canMove(cs, i, roll)) out.add(cs * 4 + i);
        return out;
    }

    public boolean isValidPiece(int seat, int piece) {
        return validPieces().contains(seat * 4 + piece);
    }

    // ------------------------------------------------------------ moves

    /** Moves the chosen piece. Returns null if the move is not legal. */
    public MoveResult move(int seat, int piece) {
        if (phase != Phase.MOVE) return null;
        if (!isValidPiece(seat, piece)) return null;

        MoveResult res = new MoveResult();
        res.seat = seat;
        res.piece = piece;
        int p = prog[seat][piece];
        res.fromProgress = p;
        int q;
        int[] path;
        if (p == -1) {
            q = 0;
            path = new int[] {0};
        } else {
            q = p + roll;
            path = new int[roll];
            for (int i = 0; i < roll; i++) path[i] = p + 1 + i;
        }
        res.toProgress = q;
        res.path = path;
        res.reachedHome = (q == Board.HOME);

        int color = seatColor[seat];
        if (q <= Board.LAST_TRACK_PROGRESS) {
            int ti = Board.trackIndex(color, q);
            res.landedOnStar = Board.isStarTrack(ti);
            if (!res.landedOnStar) {
                int mine = 1;
                List<int[]> opp = new ArrayList<int[]>();
                for (int s = 0; s < seats; s++) {
                    for (int j = 0; j < 4; j++) {
                        if (s == seat && j == piece) continue;
                        int pr = prog[s][j];
                        if (pr < 0 || pr > Board.LAST_TRACK_PROGRESS) continue;
                        if (Board.trackIndex(seatColor[s], pr) != ti) continue;
                        if (teamOf(s) == teamOf(seat)) mine++;
                        else opp.add(new int[] {s, j, pr});
                    }
                }
                // A single is cut by anyone; a pair is cut only by a pair.
                if (opp.size() == 1 || (opp.size() >= 2 && mine >= 2)) {
                    for (int[] c : opp) {
                        res.captured.add(c);
                        prog[c[0]][c[1]] = -1;
                    }
                }
            }
        }
        prog[seat][piece] = q;

        boolean extra = (roll == 6) || !res.captured.isEmpty() || res.reachedHome;
        roll = 0;

        updateFinish(seat);
        if (phase == Phase.OVER) {
            res.gameOver = true;
            res.extraTurn = false;
            return res;
        }
        boolean curDoneSolo = (mode != Mode.TEAM) && seatFinished(cur);
        if (extra && !curDoneSolo) {
            phase = Phase.ROLL;
            res.extraTurn = true;
        } else {
            advanceTurn();
        }
        return res;
    }

    private void updateFinish(int seat) {
        if (mode == Mode.TEAM) {
            int f = friendSeat(seat);
            if (seatFinished(seat) && seatFinished(f)) {
                winnerTeam = teamOf(seat);
                phase = Phase.OVER;
            }
            return;
        }
        if (seatFinished(seat) && !ranking.contains(seat)) ranking.add(seat);
        if (mode == Mode.SOLO2) {
            if (ranking.size() >= 1) {
                for (int s = 0; s < seats; s++) if (!ranking.contains(s)) ranking.add(s);
                phase = Phase.OVER;
            }
        } else if (ranking.size() >= seats - 1) {
            for (int s = 0; s < seats; s++) if (!ranking.contains(s)) ranking.add(s);
            phase = Phase.OVER;
        }
    }

    private void advanceTurn() {
        sixes = 0;
        roll = 0;
        phase = Phase.ROLL;
        for (int i = 0; i < seats; i++) {
            cur = (cur + 1) % seats;
            if (mode == Mode.TEAM || !ranking.contains(cur)) break;
        }
    }

    /** Called when a roll left no legal move: hands the turn on. */
    public boolean passTurn() {
        if (phase != Phase.MOVE) return false;
        if (!validPieces().isEmpty()) return false;
        advanceTurn();
        return true;
    }

    // ------------------------------------------------------------ save / restore

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String dec(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String join(int[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(a[i]);
        }
        return sb.toString();
    }

    private static int[] ints(String s) {
        if (s.length() == 0) return new int[0];
        String[] parts = s.split(",");
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) out[i] = Integer.parseInt(parts[i].trim());
        return out;
    }

    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("v=1\n");
        sb.append("mode=").append(mode.name()).append('\n');
        sb.append("colors=").append(join(seatColor)).append('\n');
        sb.append("names=");
        for (int i = 0; i < seats; i++) {
            if (i > 0) sb.append(',');
            sb.append(enc(names[i]));
        }
        sb.append('\n');
        int[] flat = new int[seats * 4];
        for (int s = 0; s < seats; s++) for (int p = 0; p < 4; p++) flat[s * 4 + p] = prog[s][p];
        sb.append("prog=").append(join(flat)).append('\n');
        sb.append("cur=").append(cur).append('\n');
        sb.append("sixes=").append(sixes).append('\n');
        sb.append("roll=").append(roll).append('\n');
        sb.append("phase=").append(phase.name()).append('\n');
        int[] rk = new int[ranking.size()];
        for (int i = 0; i < rk.length; i++) rk[i] = ranking.get(i);
        sb.append("rank=").append(join(rk)).append('\n');
        sb.append("win=").append(winnerTeam).append('\n');
        return sb.toString();
    }

    /** Returns null if the text is not a valid saved game. */
    public static Game deserialize(String text) {
        try {
            java.util.HashMap<String, String> m = new java.util.HashMap<String, String>();
            for (String line : text.split("\n")) {
                int i = line.indexOf('=');
                if (i > 0) m.put(line.substring(0, i), line.substring(i + 1));
            }
            Mode mode = Mode.valueOf(m.get("mode"));
            int[] colors = ints(m.get("colors"));
            String[] nameParts = m.get("names").split(",", -1);
            String[] names = new String[colors.length];
            for (int i = 0; i < names.length; i++) names[i] = dec(nameParts[i]);
            Game g = new Game(mode, colors, names, new Random(0));
            int[] flat = ints(m.get("prog"));
            if (flat.length != g.seats * 4) return null;
            for (int s = 0; s < g.seats; s++) {
                for (int p = 0; p < 4; p++) {
                    int v = flat[s * 4 + p];
                    if (v < -1 || v > Board.HOME) return null;
                    g.prog[s][p] = v;
                }
            }
            g.cur = Integer.parseInt(m.get("cur"));
            g.sixes = Integer.parseInt(m.get("sixes"));
            g.roll = Integer.parseInt(m.get("roll"));
            g.phase = Phase.valueOf(m.get("phase"));
            for (int r : ints(m.get("rank"))) g.ranking.add(r);
            g.winnerTeam = Integer.parseInt(m.get("win"));
            if (g.cur < 0 || g.cur >= g.seats) return null;
            if (g.phase == Phase.MOVE && (g.roll < 1 || g.roll > 6)) return null;
            // A saved roll whose turn could not move is handed on straight away.
            if (g.phase == Phase.MOVE && g.validPieces().isEmpty()) g.passTurn();
            return g;
        } catch (RuntimeException e) {
            return null;
        }
    }
}
