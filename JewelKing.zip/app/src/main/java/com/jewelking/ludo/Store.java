package com.jewelking.ludo;

import android.content.Context;
import android.content.SharedPreferences;

import com.jewelking.ludo.engine.Game;

/** Saves and restores the game and the sound setting. */
public final class Store {
    private static final String FILE = "jewelking";
    private static final String KEY_GAME = "game";
    private static final String KEY_MUTED = "muted";

    private final SharedPreferences prefs;

    public Store(Context ctx) {
        prefs = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Written synchronously so the state survives the app being closed at any moment. */
    public void saveGame(Game g) {
        prefs.edit().putString(KEY_GAME, g.serialize()).commit();
    }

    public Game loadGame() {
        String s = prefs.getString(KEY_GAME, null);
        if (s == null) return null;
        return Game.deserialize(s);
    }

    public void clearGame() {
        prefs.edit().remove(KEY_GAME).commit();
    }

    public boolean isMuted() {
        return prefs.getBoolean(KEY_MUTED, false);
    }

    public void setMuted(boolean muted) {
        prefs.edit().putBoolean(KEY_MUTED, muted).commit();
    }
}
