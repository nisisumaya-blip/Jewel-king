package com.jewelking.ludo;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * All game sounds, fully offline:
 *  - effects are synthesised in code and played through SoundPool,
 *  - Bengali number words and "ইস্!" use the phone's text-to-speech (if a
 *    Bengali voice is installed); otherwise number = that many beeps.
 * Everything plays on the media stream, so the phone's volume buttons control it.
 */
public final class SoundFx implements TextToSpeech.OnInitListener {
    private static final int RATE = 22050;
    private static final String[] BN_NUMBERS = {
        "\u098f\u0995", "\u09a6\u09c1\u0987", "\u09a4\u09bf\u09a8", "\u099a\u09be\u09b0", "\u09aa\u09be\u0981\u099a", "\u099b\u09af\u09bc"
    };
    private static final String BN_IS = "\u0987\u09b8!";

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<Integer> ready = new HashSet<Integer>();
    private SoundPool pool;
    private int idTipA, idTipB, idStar, idHome, idCut;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean muted;
    private boolean tipToggle = false;

    public SoundFx(Context ctx, boolean muted) {
        this.ctx = ctx.getApplicationContext();
        this.muted = muted;
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override public void onLoadComplete(SoundPool sp, int sampleId, int status) {
                if (status == 0) synchronized (ready) { ready.add(sampleId); }
            }
        });
        idTipA = load("tip_a", tone(1000, 45, 60, 0.45));
        idTipB = load("tip_b", tone(760, 45, 60, 0.45));
        idStar = load("star", starPcm());
        idHome = load("home", homePcm());
        idCut = load("cut", sweep(620, 190, 280, 0.6));
        try {
            tts = new TextToSpeech(this.ctx, this);
        } catch (RuntimeException e) {
            tts = null;
        }
    }

    // ------------------------------------------------------------------ text to speech

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) return;
        Locale[] tries = {new Locale("bn", "BD"), new Locale("bn", "IN"), new Locale("bn")};
        for (Locale l : tries) {
            int r = tts.setLanguage(l);
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                ttsReady = true;
                break;
            }
        }
        if (ttsReady) {
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
        }
    }

    public boolean hasBengaliVoice() {
        return ttsReady;
    }

    // ------------------------------------------------------------------ public API

    public boolean isMuted() {
        return muted;
    }

    public void setMuted(boolean m) {
        muted = m;
        if (m) stop();
    }

    /** Dice result, spoken in Bengali (or counted in beeps when no Bengali voice exists). */
    public void say(int number) {
        if (muted || number < 1 || number > 6) return;
        if (ttsReady && tts != null) {
            tts.speak(BN_NUMBERS[number - 1], TextToSpeech.QUEUE_FLUSH, null, "n" + number);
        } else {
            for (int i = 0; i < number; i++) {
                handler.postDelayed(new Runnable() {
                    @Override public void run() { tip(); }
                }, i * 190L);
            }
        }
    }

    /** One soft step sound; alternating pitch gives "tip tip". */
    public void tip() {
        if (muted) return;
        tipToggle = !tipToggle;
        play(tipToggle ? idTipA : idTipB);
    }

    /** Piece was cut: "ইস্!". */
    public void cut() {
        if (muted) return;
        if (ttsReady && tts != null) {
            tts.speak(BN_IS, TextToSpeech.QUEUE_FLUSH, null, "cut");
        } else {
            play(idCut);
        }
    }

    public void star() {
        if (!muted) play(idStar);
    }

    public void home() {
        if (!muted) play(idHome);
    }

    public void stop() {
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.stop();
        if (pool != null) {
            pool.autoPause();
        }
    }

    public void resume() {
        if (pool != null) pool.autoResume();
    }

    public void release() {
        handler.removeCallbacksAndMessages(null);
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (pool != null) {
            pool.release();
            pool = null;
        }
    }

    // ------------------------------------------------------------------ internals

    private void play(int id) {
        if (pool == null) return;
        synchronized (ready) {
            if (!ready.contains(id)) return;
        }
        pool.play(id, 1f, 1f, 1, 0, 1f);
    }

    private int load(String name, short[] pcm) {
        try {
            File f = new File(ctx.getCacheDir(), "fx_" + name + ".wav");
            FileOutputStream out = new FileOutputStream(f);
            try {
                out.write(wav(pcm));
            } finally {
                out.close();
            }
            return pool.load(f.getAbsolutePath(), 1);
        } catch (IOException e) {
            return -1;
        }
    }

    private static byte[] wav(short[] pcm) throws IOException {
        int dataLen = pcm.length * 2;
        ByteArrayOutputStream b = new ByteArrayOutputStream(44 + dataLen);
        b.write(new byte[] {'R', 'I', 'F', 'F'});
        le32(b, 36 + dataLen);
        b.write(new byte[] {'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        le32(b, 16);
        le16(b, 1);          // PCM
        le16(b, 1);          // mono
        le32(b, RATE);
        le32(b, RATE * 2);
        le16(b, 2);
        le16(b, 16);
        b.write(new byte[] {'d', 'a', 't', 'a'});
        le32(b, dataLen);
        for (short s : pcm) le16(b, s);
        return b.toByteArray();
    }

    private static void le16(ByteArrayOutputStream b, int v) {
        b.write(v & 0xff);
        b.write((v >> 8) & 0xff);
    }

    private static void le32(ByteArrayOutputStream b, int v) {
        le16(b, v & 0xffff);
        le16(b, (v >> 16) & 0xffff);
    }

    /** Sine tone with a quick attack and exponential decay (decayPerSec in dB-ish units). */
    private static short[] tone(double freq, int ms, double decay, double amp) {
        int n = RATE * ms / 1000;
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double attack = Math.min(1.0, t / 0.004);
            double env = attack * Math.exp(-decay * t);
            out[i] = (short) (Math.sin(2 * Math.PI * freq * t) * env * amp * 32767);
        }
        return out;
    }

    private static short[] sweep(double f0, double f1, int ms, double amp) {
        int n = RATE * ms / 1000;
        short[] out = new short[n];
        double phase = 0;
        for (int i = 0; i < n; i++) {
            double k = i / (double) n;
            double f = f0 + (f1 - f0) * k;
            phase += 2 * Math.PI * f / RATE;
            double env = Math.min(1.0, i / (RATE * 0.01)) * (1 - k);
            out[i] = (short) (Math.sin(phase) * env * amp * 32767);
        }
        return out;
    }

    private static void mix(short[] dst, short[] src, int offset) {
        for (int i = 0; i < src.length && offset + i < dst.length; i++) {
            int v = dst[offset + i] + src[i];
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            dst[offset + i] = (short) v;
        }
    }

    private static short[] starPcm() {
        short[] out = new short[RATE * 420 / 1000];
        mix(out, tone(1318, 400, 7, 0.5), 0);
        mix(out, tone(1760, 330, 8, 0.4), RATE * 90 / 1000);
        return out;
    }

    private static short[] homePcm() {
        double[] notes = {523, 659, 784, 1047};
        short[] out = new short[RATE * 700 / 1000];
        for (int i = 0; i < notes.length; i++) {
            int len = (i == notes.length - 1) ? 450 : 130;
            mix(out, tone(notes[i], len, 5, 0.5), RATE * 110 * i / 1000);
        }
        return out;
    }
}
