package com.jewelking.ludo;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.jewelking.ludo.engine.Board;
import com.jewelking.ludo.engine.Game;

import java.util.Random;

public class MainActivity extends Activity implements GameView.Host {

    private static final int[] COLOR_INT = {0xFFE5161B, 0xFF16A34A, 0xFFFFD60A, 0xFF1E88E5};
    private static final String[] COLOR_BN = {
        "\u09b2\u09be\u09b2", "\u09b8\u09ac\u09c1\u099c", "\u09b9\u09b2\u09c1\u09a6", "\u0986\u0995\u09be\u09b6\u09bf \u09a8\u09c0\u09b2"
    };
    /** Player number (1..4) -> colour, as on the board picture: P1 blue, P2 red, P3 green, P4 yellow. */
    private static final int[] PLAYER_COLOR = {Board.BLUE, Board.RED, Board.GREEN, Board.YELLOW};

    private Store store;
    private SoundFx fx;
    private GameView gameView;
    private Game current;
    private boolean inSetup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);   // volume buttons control game sound
        store = new Store(this);
        fx = new SoundFx(this, store.isMuted());
        Game saved = store.loadGame();
        if (saved != null && saved.phase != Game.Phase.OVER) {
            showGame(saved);
        } else {
            showMenu();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        if (gameView != null) gameView.onHostResume();
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.onHostPause();
        fx.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        fx.release();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.handleBack();
        } else if (inSetup) {
            showMenu();
        } else {
            super.onBackPressed();
        }
    }

    // ================================================================ GameView.Host

    @Override
    public void onMenu() {
        showMenu();
    }

    @Override
    public void onPlayAgain() {
        if (current == null) {
            showMenu();
            return;
        }
        Game ng = new Game(current.mode, current.seatColor, current.names, new Random());
        store.saveGame(ng);
        showGame(ng);
    }

    // ================================================================ screens

    private void showGame(Game g) {
        current = g;
        inSetup = false;
        gameView = new GameView(this, g, store, fx, this);
        setContentView(gameView);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout screen() {
        gameView = null;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF1B49B8);
        root.setPadding(dp(24), dp(40), dp(24), dp(24));
        return root;
    }

    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(20);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(18));
        d.setStroke(dp(2), 0xFFF5B400);
        b.setBackground(d);
        return b;
    }

    private LinearLayout.LayoutParams full(int topMarginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64));
        p.topMargin = dp(topMarginDp);
        return p;
    }

    private void showMenu() {
        inSetup = false;
        LinearLayout root = screen();
        TextView title = label("Jewel King", 40, 0xFFFFC62A, true);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
        root.addView(title);
        root.addView(label("\u0985\u09ab\u09b2\u09be\u0987\u09a8 \u2022 \u099f\u09bf\u09ae \u0986\u09aa", 16, Color.WHITE, false));

        Game saved = store.loadGame();
        if (saved != null && saved.phase != Game.Phase.OVER) {
            Button cont = button("\u099a\u09be\u09b2\u09bf\u09af\u09bc\u09c7 \u09af\u09be\u09a8", 0xFFC2410C);
            cont.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Game g = store.loadGame();
                    if (g != null) showGame(g);
                }
            });
            root.addView(cont, full(36));
        }
        Button b2 = button("\u09e8 \u099c\u09a8 \u0996\u09c7\u09b2\u09ac\u09c7", 0xFF16A34A);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSetup(Game.Mode.SOLO2); }
        });
        Button b4 = button("\u09ea \u099c\u09a8 \u0996\u09c7\u09b2\u09ac\u09c7", 0xFF1E88E5);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSetup(Game.Mode.SOLO4); }
        });
        Button bt = button("\u09e8 \u09ac\u09a8\u09be\u09ae \u09e8  Team Up", 0xFF7C3AED);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSetup(Game.Mode.TEAM); }
        });
        root.addView(b2, full(saved != null && saved.phase != Game.Phase.OVER ? 16 : 36));
        root.addView(b4, full(16));
        root.addView(bt, full(16));
        setContentView(root);
    }

    // ---- setup (names, and colours for 2 players) ---------------------------------

    private void showSetup(final Game.Mode mode) {
        inSetup = true;
        final int n = (mode == Game.Mode.SOLO2) ? 2 : 4;
        final EditText[] names = new EditText[n];
        final int[] pickedColor = new int[n];
        final View[][] swatch = new View[n][4];

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF1B49B8);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        scroll.addView(root);

        String head = (mode == Game.Mode.SOLO2) ? "\u09e8 \u099c\u09a8\u09c7\u09b0 \u0996\u09c7\u09b2\u09be"
                : (mode == Game.Mode.SOLO4 ? "\u09ea \u099c\u09a8\u09c7\u09b0 \u0996\u09c7\u09b2\u09be" : "\u09e8 \u09ac\u09a8\u09be\u09ae \u09e8  Team Up");
        root.addView(label(head, 26, 0xFFFFC62A, true));
        root.addView(label("\u0996\u09c7\u09b2\u09cb\u09af\u09bc\u09be\u09a1\u09bc\u09c7\u09b0 \u09a8\u09be\u09ae \u09b2\u09bf\u0996\u09c1\u09a8", 16, Color.WHITE, false));

        for (int i = 0; i < n; i++) {
            final int idx = i;
            int color = (mode == Game.Mode.SOLO2) ? (i == 0 ? Board.BLUE : Board.RED) : PLAYER_COLOR[i];
            pickedColor[i] = color;

            TextView tag = new TextView(this);
            String extra = "";
            if (mode == Game.Mode.TEAM) {
                extra = (color == Board.GREEN || color == Board.BLUE) ? "  \u2022  TEAM A" : "  \u2022  TEAM B";
            }
            tag.setText("Player " + (i + 1) + (mode == Game.Mode.SOLO2 ? "" : "  \u2022  " + COLOR_BN[color]) + extra);
            tag.setTextColor(Color.WHITE);
            tag.setTextSize(16);
            tag.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = dp(22);
            root.addView(tag, tp);

            EditText et = new EditText(this);
            et.setText("Player " + (i + 1));
            et.setSingleLine(true);
            et.setFilters(new InputFilter[] {new InputFilter.LengthFilter(14)});
            et.setTextColor(Color.WHITE);
            et.setHintTextColor(0x88FFFFFF);
            et.setTextSize(20);
            names[i] = et;
            root.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            if (mode == Game.Mode.SOLO2) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int c = 0; c < 4; c++) {
                    final int col = c;
                    View sw = new View(this);
                    swatch[i][c] = sw;
                    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(48), 1f);
                    sp.rightMargin = dp(8);
                    sp.topMargin = dp(8);
                    sw.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            pickedColor[idx] = col;
                            paintSwatches(swatch, pickedColor);
                        }
                    });
                    row.addView(sw, sp);
                }
                root.addView(row);
            }
        }
        if (mode == Game.Mode.SOLO2) paintSwatches(swatch, pickedColor);

        final TextView error = label("", 15, 0xFFFFB4B4, true);
        root.addView(error);

        Button start = button("\u0996\u09c7\u09b2\u09be \u09b6\u09c1\u09b0\u09c1", 0xFF16A34A);
        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (mode == Game.Mode.SOLO2 && pickedColor[0] == pickedColor[1]) {
                    error.setText("\u09a6\u09c1\u099c\u09a8 \u098f\u0995\u0987 \u09b0\u0982 \u09a8\u09bf\u09a4\u09c7 \u09aa\u09be\u09b0\u09ac\u09c7 \u09a8\u09be\u0964 \u0986\u09b2\u09be\u09a6\u09be \u09b0\u0982 \u09ac\u09be\u099b\u09c1\u09a8\u0964");
                    return;
                }
                String[] nm = new String[n];
                for (int i = 0; i < n; i++) {
                    String s = names[i].getText().toString().trim();
                    nm[i] = s.length() == 0 ? "Player " + (i + 1) : s;
                }
                startNewGame(mode, pickedColor, nm);
            }
        });
        root.addView(start, full(26));
        Button back = button("\u09aa\u09c7\u099b\u09a8\u09c7", 0xFF475569);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        root.addView(back, full(12));
        setContentView(scroll);
    }

    private void paintSwatches(View[][] swatch, int[] picked) {
        for (int i = 0; i < swatch.length; i++) {
            for (int c = 0; c < 4; c++) {
                GradientDrawable d = new GradientDrawable();
                d.setColor(COLOR_INT[c]);
                d.setCornerRadius(dp(12));
                boolean sel = picked[i] == c;
                d.setStroke(dp(sel ? 5 : 1), sel ? Color.WHITE : 0x66000000);
                swatch[i][c].setBackground(d);
            }
        }
    }

    /** Builds a game: seats are ordered clockwise by colour (red, green, yellow, blue). */
    private void startNewGame(Game.Mode mode, int[] colorOfPlayer, String[] nameOfPlayer) {
        int n = colorOfPlayer.length;
        int[] colors;
        String[] names;
        if (mode == Game.Mode.SOLO2) {
            colors = new int[2];
            names = new String[2];
            int first = colorOfPlayer[0] < colorOfPlayer[1] ? 0 : 1;
            colors[0] = colorOfPlayer[first];
            names[0] = nameOfPlayer[first];
            colors[1] = colorOfPlayer[1 - first];
            names[1] = nameOfPlayer[1 - first];
        } else {
            colors = new int[] {Board.RED, Board.GREEN, Board.YELLOW, Board.BLUE};
            names = new String[4];
            for (int p = 0; p < n; p++) {
                for (int s = 0; s < 4; s++) {
                    if (colors[s] == PLAYER_COLOR[p]) names[s] = nameOfPlayer[p];
                }
            }
        }
        Game g = new Game(mode, colors, names, new Random());
        store.saveGame(g);
        showGame(g);
    }
}
