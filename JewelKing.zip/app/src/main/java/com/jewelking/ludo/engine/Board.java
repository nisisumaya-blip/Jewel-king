package com.jewelking.ludo.engine;

/**
 * Board geometry. 15x15 grid, 52 outer track squares numbered clockwise.
 * Colours in clockwise order: RED (top-left), GREEN (top-right),
 * YELLOW (bottom-right), BLUE (bottom-left).
 *
 * A piece's "progress": -1 = in base, 0 = its start square, 1..50 = further
 * track squares, 51..55 = its home column, 56 = finished (home).
 */
public final class Board {
    private Board() {}

    public static final int RED = 0, GREEN = 1, YELLOW = 2, BLUE = 3;
    public static final int TRACK = 52;
    public static final int LAST_TRACK_PROGRESS = 50;
    public static final int HOME = 56;

    /** Track index of each colour's start square. */
    public static final int[] START = {1, 14, 27, 40};

    /** The 8 safe star squares (track indexes). Start squares are NOT safe. */
    private static final int[] STARS = {2, 9, 15, 22, 28, 35, 41, 48};

    /** {row, col} of each of the 52 track squares, clockwise from (6,0). */
    private static final int[][] TRACK_CELLS = {
        {6, 0}, {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5},
        {5, 6}, {4, 6}, {3, 6}, {2, 6}, {1, 6}, {0, 6},
        {0, 7},
        {0, 8}, {1, 8}, {2, 8}, {3, 8}, {4, 8}, {5, 8},
        {6, 9}, {6, 10}, {6, 11}, {6, 12}, {6, 13}, {6, 14},
        {7, 14},
        {8, 14}, {8, 13}, {8, 12}, {8, 11}, {8, 10}, {8, 9},
        {9, 8}, {10, 8}, {11, 8}, {12, 8}, {13, 8}, {14, 8},
        {14, 7},
        {14, 6}, {13, 6}, {12, 6}, {11, 6}, {10, 6}, {9, 6},
        {8, 5}, {8, 4}, {8, 3}, {8, 2}, {8, 1}, {8, 0},
        {7, 0}
    };

    /** Home column cells per colour, progress 51..55 -> index 0..4. */
    private static final int[][][] HOME_COLUMN = {
        {{7, 1}, {7, 2}, {7, 3}, {7, 4}, {7, 5}},          // red
        {{1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}},          // green
        {{7, 13}, {7, 12}, {7, 11}, {7, 10}, {7, 9}},      // yellow
        {{13, 7}, {12, 7}, {11, 7}, {10, 7}, {9, 7}}       // blue
    };

    public static boolean isStarTrack(int trackIdx) {
        for (int s : STARS) if (s == trackIdx) return true;
        return false;
    }

    public static int[] starTracks() {
        return STARS.clone();
    }

    /** Track index for progress 0..50. */
    public static int trackIndex(int color, int progress) {
        return (START[color] + progress) % TRACK;
    }

    public static int[] trackCell(int trackIdx) {
        return new int[] {TRACK_CELLS[trackIdx][0], TRACK_CELLS[trackIdx][1]};
    }

    /** {row, col} for progress 0..55; progress 56 returns the centre {7,7}. */
    public static int[] cell(int color, int progress) {
        if (progress >= HOME) return new int[] {7, 7};
        if (progress <= LAST_TRACK_PROGRESS) return trackCell(trackIndex(color, progress));
        int[] c = HOME_COLUMN[color][progress - 51];
        return new int[] {c[0], c[1]};
    }

    /** True when two pieces occupy the same physical square (progress 0..55 only). */
    public static boolean sameSquare(int colorA, int progA, int colorB, int progB) {
        if (progA < 0 || progB < 0 || progA >= HOME || progB >= HOME) return false;
        boolean aTrack = progA <= LAST_TRACK_PROGRESS;
        boolean bTrack = progB <= LAST_TRACK_PROGRESS;
        if (aTrack && bTrack) return trackIndex(colorA, progA) == trackIndex(colorB, progB);
        if (!aTrack && !bTrack) return colorA == colorB && progA == progB;
        return false;
    }
}
