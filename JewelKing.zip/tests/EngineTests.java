import com.jewelking.ludo.engine.Board;
import com.jewelking.ludo.engine.Game;

import java.util.*;

/** Plain-Java tests for the rules engine. Run: see README (or the GitHub workflow). */
public class EngineTests {
    static int checks = 0, fails = 0;

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) {
            fails++;
            System.out.println("FAIL: " + what);
        }
    }

    /** Random source that returns scripted values for nextInt(bound). */
    static class Fixed extends Random {
        final int[] seq; int i = 0;
        Fixed(int... seq) { this.seq = seq; }
        @Override public int nextInt(int bound) { return seq[i++ % seq.length] % bound; }
    }

    static Game solo4() {
        return new Game(Game.Mode.SOLO4, new int[] {0, 1, 2, 3}, new String[] {"R", "G", "Y", "B"}, new Random(1));
    }
    static Game team() {
        return new Game(Game.Mode.TEAM, new int[] {0, 1, 2, 3}, new String[] {"R", "G", "Y", "B"}, new Random(1));
    }
    static Game solo2() {
        return new Game(Game.Mode.SOLO2, new int[] {0, 3}, new String[] {"R", "B"}, new Random(1));
    }
    static void setMove(Game g, int seat, int roll) {
        g.cur = seat; g.roll = roll; g.phase = Game.Phase.MOVE;
    }
    static int progForTrack(int color, int trackIdx) {
        return (trackIdx - Board.START[color] + 52) % 52;
    }

    public static void main(String[] args) {
        boardTests();
        diceTests();
        movementTests();
        captureTests();
        teamTests();
        turnTests();
        endTests();
        saveTests();
        playouts();
        System.out.println(checks + " checks, " + fails + " failures");
        if (fails > 0) System.exit(1);
    }

    // ------------------------------------------------------------------ board
    static void boardTests() {
        Set<String> seen = new HashSet<String>();
        for (int i = 0; i < 52; i++) {
            int[] c = Board.trackCell(i);
            check(seen.add(c[0] + "," + c[1]), "track cell unique " + i);
            int[] n = Board.trackCell((i + 1) % 52);
            check(Math.abs(c[0] - n[0]) <= 1 && Math.abs(c[1] - n[1]) <= 1, "track adjacent " + i);
        }
        check(seen.size() == 52, "52 track squares");
        int[][] starts = {{6, 1}, {1, 8}, {8, 13}, {13, 6}};
        for (int c = 0; c < 4; c++) {
            int[] s = Board.cell(c, 0);
            check(s[0] == starts[c][0] && s[1] == starts[c][1], "start square colour " + c);
            // progress cells unique per colour, 56 -> centre
            Set<String> mine = new HashSet<String>();
            for (int p = 0; p <= 55; p++) {
                int[] cell = Board.cell(c, p);
                check(mine.add(cell[0] + "," + cell[1]), "colour " + c + " progress cell unique " + p);
            }
            int[] a = Board.cell(c, 50), b = Board.cell(c, 51);
            check(Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) == 1, "home column joins track, colour " + c);
            for (int p = 51; p < 55; p++) {
                int[] x = Board.cell(c, p), y = Board.cell(c, p + 1);
                check(Math.abs(x[0] - y[0]) + Math.abs(x[1] - y[1]) == 1, "home column contiguous");
            }
            int[] h = Board.cell(c, 56);
            check(h[0] == 7 && h[1] == 7, "home is centre");
        }
        // 8 stars, exactly the squares in the reference picture
        int[][] stars = {{6, 2}, {8, 2}, {2, 6}, {2, 8}, {6, 12}, {8, 12}, {12, 6}, {12, 8}};
        int n = 0;
        for (int i = 0; i < 52; i++) if (Board.isStarTrack(i)) n++;
        check(n == 8, "exactly 8 star squares");
        for (int[] s : stars) {
            boolean found = false;
            for (int i = 0; i < 52; i++) {
                int[] c = Board.trackCell(i);
                if (c[0] == s[0] && c[1] == s[1] && Board.isStarTrack(i)) found = true;
            }
            check(found, "star at " + s[0] + "," + s[1]);
        }
        for (int c = 0; c < 4; c++) check(!Board.isStarTrack(Board.START[c]), "start square not safe " + c);
    }

    // ------------------------------------------------------------------ dice
    static void diceTests() {
        Game g = solo4();
        Random r = new Random(42);
        int[] cnt = new int[7];
        int N = 600000;
        for (int i = 0; i < N; i++) {
            g.phase = Game.Phase.ROLL; g.sixes = 0;
            cnt[g.roll(r)]++;
        }
        for (int v = 1; v <= 6; v++) check(Math.abs(cnt[v] - N / 6) < 1500, "dice fair for " + v + " (" + cnt[v] + ")");

        int[] c2 = new int[7];
        for (int i = 0; i < 300000; i++) {
            g.phase = Game.Phase.ROLL; g.sixes = 2;
            c2[g.roll(r)]++;
        }
        check(c2[6] == 0, "after two sixes no six");
        for (int v = 1; v <= 5; v++) check(Math.abs(c2[v] - 60000) < 1200, "after two sixes 1-5 equal " + v);

        // scripted: 6, 6, then forced 1-5
        Game h = solo4();
        Fixed f = new Fixed(5, 5, 4);
        h.phase = Game.Phase.ROLL;
        check(h.roll(f) == 6 && h.sixes == 1, "first six counted");
        h.phase = Game.Phase.ROLL;
        check(h.roll(f) == 6 && h.sixes == 2, "second six counted");
        h.phase = Game.Phase.ROLL;
        int v = h.roll(f);
        check(v >= 1 && v <= 5 && h.sixes == 0, "third roll 1-5, counter reset");

        // extra tap while rolling is ignored: roll() when not in ROLL phase does nothing
        Game k = solo4();
        int first = k.roll(new Random(7));
        int again = k.roll(new Random(8));
        check(again == 0 && k.roll == first, "second roll request ignored, result kept");
    }

    // ------------------------------------------------------------------ movement
    static void movementTests() {
        Game g = solo4();
        setMove(g, 0, 5);
        check(g.validPieces().isEmpty(), "no exit without six");
        check(g.passTurn() && g.cur == 1 && g.phase == Game.Phase.ROLL, "no valid move passes turn");
        setMove(g, 0, 6);
        check(g.validPieces().size() == 4, "all four base pieces can exit on six");
        Game.MoveResult m = g.move(0, 2);
        check(m != null && g.prog[0][2] == 0 && m.extraTurn && g.cur == 0 && g.phase == Game.Phase.ROLL, "exit on six + extra turn");

        // own start square occupied: base pieces blocked, the piece on start can move
        g = solo4(); g.prog[0][0] = 0; setMove(g, 0, 6);
        List<Integer> v = g.validPieces();
        check(!v.contains(1) && !v.contains(2) && !v.contains(3) && v.contains(0), "own piece on start blocks exit");

        // own pieces cannot share a square
        g = solo4(); g.prog[0][0] = 5; g.prog[0][1] = 8; setMove(g, 0, 3);
        check(!g.validPieces().contains(0) && g.validPieces().contains(1), "own pieces never share");

        // exact count to finish
        g = solo4(); g.prog[0][0] = 52; setMove(g, 0, 5);
        check(!g.validPieces().contains(0), "overshoot not allowed");
        setMove(g, 0, 4);
        m = g.move(0, 0);
        check(m != null && m.reachedHome && g.prog[0][0] == 56 && m.extraTurn && g.cur == 0, "exact finish gives extra turn");
        g = solo4(); g.prog[0][0] = 56; setMove(g, 0, 1);
        check(!g.validPieces().contains(0), "finished piece cannot move");

        // several pieces may finish together in the centre
        g = solo4(); g.prog[0][0] = 56; g.prog[0][1] = 55; setMove(g, 0, 1);
        check(g.validPieces().contains(1), "can join finished pieces");

        // a pending move needs a chosen piece: nothing moves by itself
        g = solo4(); g.prog[0][0] = 10; setMove(g, 0, 3);
        check(g.validPieces().size() == 1 && g.prog[0][0] == 10 && g.phase == Game.Phase.MOVE, "single valid piece is not auto-moved");

        // illegal choice rejected
        check(g.move(0, 1) == null, "illegal piece rejected");

        // path content
        g = solo4(); g.prog[0][0] = 10; setMove(g, 0, 3);
        m = g.move(0, 0);
        check(Arrays.equals(m.path, new int[] {11, 12, 13}), "path steps");
    }

    // ------------------------------------------------------------------ captures
    static void captureTests() {
        // single capture on normal square
        Game g = solo4();
        g.prog[0][0] = progForTrack(0, 4);
        g.prog[1][0] = progForTrack(1, 5);
        setMove(g, 0, 1);
        Game.MoveResult m = g.move(0, 0);
        check(m.captured.size() == 1 && g.prog[1][0] == -1 && m.extraTurn && g.cur == 0, "capture single, extra turn");
        check(g.prog[0][0] == progForTrack(0, 5), "capturer lands on square");

        // star square is safe
        g = solo4();
        g.prog[0][0] = progForTrack(0, 1);
        g.prog[1][0] = progForTrack(1, 2);
        setMove(g, 0, 1);
        m = g.move(0, 0);
        check(m.captured.isEmpty() && m.landedOnStar && g.prog[1][0] != -1, "star square safe, both stay");
        check(!m.extraTurn && g.cur == 1, "no capture, no extra turn");

        // start square is not safe: exit cuts a lone opponent there
        g = solo4();
        g.prog[1][0] = progForTrack(1, Board.START[0]);   // green sits on red's start
        setMove(g, 0, 6);
        m = g.move(0, 0);
        check(m.captured.size() == 1 && g.prog[1][0] == -1, "exit cuts lone opponent on start square");

        // in solo, two different players never share a normal square
        g = solo4();
        g.prog[0][0] = progForTrack(0, 20);
        g.prog[3][0] = progForTrack(3, 18);
        setMove(g, 3, 2);
        m = g.move(3, 0);
        check(m.captured.size() == 1 && g.prog[0][0] == -1, "solo: single cut by single");

        // home column is private
        g = solo4(); g.prog[0][0] = 49; g.prog[1][0] = 49; setMove(g, 0, 3);
        m = g.move(0, 0);
        check(m.captured.isEmpty(), "home column is safe");
    }

    // ------------------------------------------------------------------ team up
    static void teamTests() {
        // seats: 0 red(B) 1 green(A) 2 yellow(B) 3 blue(A)
        Game g = team();
        check(g.teamOf(1) == 0 && g.teamOf(3) == 0 && g.teamOf(0) == 1 && g.teamOf(2) == 1, "team membership");
        check(g.friendSeat(1) == 3 && g.friendSeat(0) == 2, "friend seat");

        // friends form a pair, no capture
        g.prog[1][0] = progForTrack(1, 20);
        g.prog[3][0] = progForTrack(3, 17);
        setMove(g, 3, 3);
        check(g.validPieces().contains(12), "friend may join friend");
        Game.MoveResult m = g.move(3, 0);
        check(m.captured.isEmpty() && g.prog[1][0] != -1 && g.prog[3][0] == progForTrack(3, 20), "friends pair, nothing cut");

        // same player's own two pieces still cannot share
        g = team();
        g.prog[1][0] = progForTrack(1, 20); g.prog[1][1] = progForTrack(1, 17);
        setMove(g, 1, 3);
        check(!g.validPieces().contains(5), "own two pieces never pair, even in Team Up");

        // pair cut by pair (both opposing pieces go home)
        g = team();
        g.prog[0][0] = progForTrack(0, 30);
        g.prog[2][0] = progForTrack(2, 30);
        g.prog[1][0] = progForTrack(1, 30);
        g.prog[3][0] = progForTrack(3, 27);
        setMove(g, 3, 3);
        m = g.move(3, 0);
        check(m.captured.size() == 2 && g.prog[0][0] == -1 && g.prog[2][0] == -1, "pair cuts pair, both return");

        // single cannot cut a pair, but may sit with it
        g = team();
        g.prog[0][0] = progForTrack(0, 30);
        g.prog[2][0] = progForTrack(2, 30);
        g.prog[1][0] = progForTrack(1, 27);
        setMove(g, 1, 3);
        check(g.validPieces().contains(4), "single may land on a pair's square");
        m = g.move(1, 0);
        check(m.captured.isEmpty() && g.prog[0][0] != -1 && g.prog[2][0] != -1 && g.prog[1][0] == progForTrack(1, 30), "single does not cut pair");

        // pair arriving onto a lone opponent cuts it
        g = team();
        g.prog[0][0] = progForTrack(0, 30);
        g.prog[1][0] = progForTrack(1, 27);
        g.prog[3][0] = progForTrack(3, 30);
        g.prog[3][0] = progForTrack(3, 31);   // friend two squares on
        // blue sits at 31; green moves 4 -> 31 forming a pair there, lone red sits at 31
        g.prog[0][0] = progForTrack(0, 31);
        setMove(g, 1, 4);
        m = g.move(1, 0);
        check(m.captured.size() == 1 && g.prog[0][0] == -1, "lone opponent cut when arriving next to a friend");

        // star squares: everybody may share, nobody is cut
        g = team();
        g.prog[0][0] = progForTrack(0, 9);
        g.prog[1][0] = progForTrack(1, 6);
        setMove(g, 1, 3);
        m = g.move(1, 0);
        check(m.captured.isEmpty() && g.prog[0][0] != -1, "team: star is safe");

        // own four home -> may move the friend's pieces
        g = team();
        for (int p = 0; p < 4; p++) g.prog[1][p] = 56;
        g.prog[3][0] = 10;
        setMove(g, 1, 4);
        check(g.controlSeat() == 3, "control passes to friend");
        List<Integer> v = g.validPieces();
        check(v.size() == 1 && v.get(0) == 12, "only friend's movable piece is valid");
        m = g.move(3, 0);
        check(m != null && g.prog[3][0] == 14, "friend piece moved by teammate's roll");

        // team wins when all eight are home
        g = team();
        for (int p = 0; p < 4; p++) { g.prog[1][p] = 56; g.prog[3][p] = 56; }
        g.prog[3][3] = 55;
        setMove(g, 1, 1);
        m = g.move(3, 3);
        check(m.gameOver && g.phase == Game.Phase.OVER && g.winnerTeam == 0, "team wins with all eight home");

        // team does not win with only one friend finished
        g = team();
        for (int p = 0; p < 4; p++) g.prog[1][p] = 56;
        g.prog[1][3] = 55;
        for (int p = 0; p < 4; p++) g.prog[3][p] = 10 + p;
        setMove(g, 1, 1);
        m = g.move(1, 3);
        check(!m.gameOver && g.phase == Game.Phase.ROLL, "no win until both friends are home");
    }

    // ------------------------------------------------------------------ turns
    static void turnTests() {
        Game g = solo4();
        g.prog[0][0] = 10;
        setMove(g, 0, 6);
        Game.MoveResult m = g.move(0, 0);
        check(m.extraTurn && g.cur == 0 && g.sixes == 0 /* roll() wasn't used */, "six gives extra turn");

        g = solo4(); g.prog[0][0] = 10; setMove(g, 0, 2);
        m = g.move(0, 0);
        check(!m.extraTurn && g.cur == 1, "plain move passes turn clockwise");
        g.cur = 3; g.phase = Game.Phase.ROLL; g.prog[3][0] = 10; setMove(g, 3, 2);
        g.move(3, 0);
        check(g.cur == 0, "order wraps blue -> red");

        // clockwise order red -> green -> yellow -> blue
        g = solo4();
        int[] order = new int[4];
        g.cur = 0;
        for (int i = 0; i < 4; i++) { order[i] = g.cur; setMove(g, g.cur, 5); g.passTurn(); }
        check(Arrays.equals(order, new int[] {0, 1, 2, 3}), "turn order clockwise");

        // two-player: only the two chosen colours
        g = solo2();
        g.cur = 0; setMove(g, 0, 5); g.passTurn();
        check(g.cur == 1, "2-player alternates");
        setMove(g, 1, 5); g.passTurn();
        check(g.cur == 0, "2-player wraps");

        // roll is stored: phase becomes MOVE, can't roll again until the move is done
        g = solo4(); g.cur = 0;
        int v = g.roll(new Random(3));
        check(g.phase == Game.Phase.MOVE && g.roll == v, "roll stored");
        check(g.roll(new Random(9)) == 0, "no re-roll before the move");
        check(!g.passTurn() || g.validPieces().isEmpty(), "cannot pass while a move exists");
    }

    // ------------------------------------------------------------------ endings
    static void endTests() {
        Game g = solo4();
        for (int p = 0; p < 3; p++) g.prog[0][p] = 56;
        g.prog[0][3] = 55; g.prog[1][0] = 10;
        setMove(g, 0, 1);
        Game.MoveResult m = g.move(0, 3);
        check(g.ranking.size() == 1 && g.ranking.get(0) == 0 && g.phase == Game.Phase.ROLL, "first finisher ranked, game continues");
        check(g.cur == 1, "finished player does not keep the turn");
        // finished player is skipped afterwards
        g.cur = 3; g.phase = Game.Phase.ROLL; setMove(g, 3, 5); g.passTurn();
        check(g.cur == 1, "finished player skipped");

        // second and third finishers end the game with 4 ranks
        for (int p = 0; p < 3; p++) g.prog[1][p] = 56;
        g.prog[1][3] = 55; setMove(g, 1, 1);
        g.move(1, 3);
        check(g.ranking.size() == 2 && g.phase == Game.Phase.ROLL, "second finisher");
        for (int p = 0; p < 3; p++) g.prog[2][p] = 56;
        g.prog[2][3] = 55; setMove(g, 2, 1);
        m = g.move(2, 3);
        check(m.gameOver && g.phase == Game.Phase.OVER && g.ranking.size() == 4 && g.ranking.get(3) == 3, "game ends when ranks decided");

        // two player ends at first finisher
        g = solo2();
        for (int p = 0; p < 3; p++) g.prog[0][p] = 56;
        g.prog[0][3] = 55; setMove(g, 0, 1);
        m = g.move(0, 3);
        check(m.gameOver && g.ranking.get(0) == 0 && g.ranking.size() == 2, "2-player ends at first finisher");
        check(g.roll(new Random(1)) == 0 && g.move(0, 0) == null, "nothing moves after game over");
    }

    // ------------------------------------------------------------------ save / restore
    static String dump(Game g) { return g.serialize(); }

    static void saveTests() {
        Game g = new Game(Game.Mode.TEAM, new int[] {0, 1, 2, 3}, new String[] {"\u0986\u09b0\u09bf\u09ab, x", "B=2", "\u09a4\u09be\u09ac\u09be\u09b8\u09b8\u09c1\u09ae\n", "D"}, new Random(5));
        g.prog[1][0] = 33; g.prog[2][1] = -1; g.prog[3][2] = 56;
        g.cur = 1; g.sixes = 1;
        int v = g.roll(new Random(11));
        Game h = Game.deserialize(g.serialize());
        check(h != null && dump(h).equals(dump(g)), "round trip with pending roll");
        check(h.names[0].equals("\u0986\u09b0\u09bf\u09ab, x") && h.names[2].equals("\u09a4\u09be\u09ac\u09be\u09b8\u09b8\u09c1\u09ae\n"), "names survive");
        check(h.phase == g.phase && h.roll == g.roll && h.validPieces().equals(g.validPieces()), "pending roll and valid pieces restored");
        check(h.sixes == g.sixes, "six counter restored");

        // restore mid-move: move applied once only
        g = solo4(); g.prog[0][0] = progForTrack(0, 4); g.prog[1][0] = progForTrack(1, 5);
        setMove(g, 0, 1);
        g.move(0, 0);
        String saved = g.serialize();
        Game r = Game.deserialize(saved);
        check(r.prog[1][0] == -1 && r.prog[0][0] == progForTrack(0, 5), "capture persisted");
        check(r.move(0, 0) == null || r.roll == 0, "restored game cannot repeat the move");
        check(r.phase == Game.Phase.ROLL && r.cur == 0, "extra turn restored");
        check(r.serialize().equals(saved), "restored state unchanged");

        // a saved roll with no legal move is handed on
        g = solo4(); setMove(g, 0, 3);
        Game q = Game.deserialize(g.serialize());
        check(q.phase == Game.Phase.ROLL && q.cur == 1, "unusable saved roll passes turn on restore");

        check(Game.deserialize("garbage") == null, "garbage rejected");
        check(Game.deserialize("") == null, "empty rejected");

        // finished and ranking state survive
        g = solo4(); g.ranking.add(2); for (int p = 0; p < 4; p++) g.prog[2][p] = 56;
        Game z = Game.deserialize(g.serialize());
        check(z.ranking.equals(g.ranking), "ranking restored");
    }

    // ------------------------------------------------------------------ playouts
    static int cellCount(Game g, int track) {
        int n = 0;
        for (int s = 0; s < g.seats; s++) for (int p = 0; p < 4; p++) {
            int pr = g.prog[s][p];
            if (pr >= 0 && pr <= 50 && Board.trackIndex(g.seatColor[s], pr) == track) n++;
        }
        return n;
    }

    static void invariants(Game g, String ctx) {
        for (int s = 0; s < g.seats; s++) {
            for (int a = 0; a < 4; a++) {
                int pa = g.prog[s][a];
                if (pa < -1 || pa > 56) { check(false, ctx + " progress range"); return; }
                for (int b = a + 1; b < 4; b++) {
                    int pb = g.prog[s][b];
                    if (pa >= 0 && pa < 56 && pa == pb) { check(false, ctx + " own pieces share a square"); return; }
                }
            }
        }
        for (int t = 0; t < 52; t++) {
            if (Board.isStarTrack(t)) continue;
            int[] perTeam = new int[4];
            for (int s = 0; s < g.seats; s++) for (int p = 0; p < 4; p++) {
                int pr = g.prog[s][p];
                if (pr >= 0 && pr <= 50 && Board.trackIndex(g.seatColor[s], pr) == t) perTeam[g.teamOf(s)]++;
            }
            if (g.mode != Game.Mode.TEAM) {
                int tot = perTeam[0] + perTeam[1] + perTeam[2] + perTeam[3];
                if (tot > 1) { check(false, ctx + " solo: two pieces on a normal square"); return; }
            } else {
                if (perTeam[0] > 2 || perTeam[1] > 2) { check(false, ctx + " more than a pair"); return; }
                // Note: a single may legitimately sit beside another team's single after
                // a pair that shared the square has split up; the next arrival cuts them.
            }
        }
    }

    static void playouts() {
        Game.Mode[] modes = {Game.Mode.SOLO2, Game.Mode.SOLO4, Game.Mode.TEAM};
        for (Game.Mode mode : modes) {
            int finished = 0, maxSteps = 0, captures = 0, sixesTotal = 0;
            for (int seed = 0; seed < 1500; seed++) {
                Random rnd = new Random(seed * 31L + 7);
                Game g;
                if (mode == Game.Mode.SOLO2) g = new Game(mode, new int[] {0, 2}, new String[] {"a", "b"}, rnd);
                else g = new Game(mode, new int[] {0, 1, 2, 3}, new String[] {"a", "b", "c", "d"}, rnd);
                int steps = 0;
                boolean ok = true;
                while (g.phase != Game.Phase.OVER && steps < 200000) {
                    steps++;
                    if (g.phase == Game.Phase.ROLL) {
                        int v = g.roll(rnd);
                        if (v < 1 || v > 6 || g.sixes > 2) { check(false, "bad roll"); ok = false; break; }
                        if (v == 6) sixesTotal++;
                        continue;
                    }
                    List<Integer> valid = g.validPieces();
                    if (valid.isEmpty()) { g.passTurn(); continue; }
                    int id = valid.get(rnd.nextInt(valid.size()));
                    Game.MoveResult m = g.move(id / 4, id % 4);
                    if (m == null) { check(false, "valid piece refused"); ok = false; break; }
                    captures += m.captured.size();
                    invariants(g, mode + " seed " + seed);
                    // serialisation always round-trips
                    if (steps % 97 == 0) {
                        Game r = Game.deserialize(g.serialize());
                        if (r == null || !r.serialize().equals(g.serialize())) { check(false, "playout round trip"); ok = false; break; }
                    }
                }
                if (!ok) break;
                check(g.phase == Game.Phase.OVER, mode + " game ended (seed " + seed + ")");
                if (g.phase == Game.Phase.OVER) {
                    finished++;
                    maxSteps = Math.max(maxSteps, steps);
                    if (mode == Game.Mode.TEAM) {
                        check(g.winnerTeam >= 0, "team winner set");
                    } else {
                        check(g.ranking.size() == g.seats, mode + " ranking complete");
                        check(new HashSet<Integer>(g.ranking).size() == g.seats, mode + " ranking unique");
                    }
                }
            }
            System.out.println(mode + ": " + finished + " games finished, longest " + maxSteps + " steps, "
                    + captures + " captures, " + sixesTotal + " sixes");
        }
    }
}
